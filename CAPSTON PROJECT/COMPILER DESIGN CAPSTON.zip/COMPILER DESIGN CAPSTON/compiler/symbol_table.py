"""
Supporting Component: Scoped Symbol Table Management
Tracks variables, types, scopes, initialized status, and usages.
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field


@dataclass
class Symbol:
    name: str
    var_type: str
    line: int
    column: int
    scope_level: int
    is_initialized: bool = False
    usage_count: int = 0

    def to_dict(self):
        return {
            "name": self.name,
            "type": self.var_type,
            "line": self.line,
            "column": self.column,
            "scope_level": self.scope_level,
            "is_initialized": self.is_initialized,
            "usage_count": self.usage_count,
        }


class SymbolTable:
    """Hierarchical scoped symbol table."""

    def __init__(self, parent: Optional["SymbolTable"] = None, scope_name: str = "global"):
        self.parent = parent
        self.scope_name = scope_name
        self.scope_level = 0 if parent is None else parent.scope_level + 1
        self.symbols: Dict[str, Symbol] = {}

    def insert(self, name: str, var_type: str, line: int, column: int, is_initialized: bool = False) -> bool:
        """Insert symbol into current scope. Returns False if already declared in this scope."""
        if name in self.symbols:
            return False
        self.symbols[name] = Symbol(
            name=name,
            var_type=var_type,
            line=line,
            column=column,
            scope_level=self.scope_level,
            is_initialized=is_initialized,
            usage_count=0
        )
        return True

    def lookup(self, name: str, mark_used: bool = False) -> Optional[Symbol]:
        """Look up symbol in current scope or enclosing parent scopes."""
        if name in self.symbols:
            sym = self.symbols[name]
            if mark_used:
                sym.usage_count += 1
            return sym
        if self.parent:
            return self.parent.lookup(name, mark_used=mark_used)
        return None

    def get_all_visible_symbols(self) -> List[str]:
        """Returns list of all symbol names visible from this scope."""
        names = list(self.symbols.keys())
        if self.parent:
            names.extend(self.parent.get_all_visible_symbols())
        return list(set(names))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scope": self.scope_name,
            "level": self.scope_level,
            "symbols": {k: v.to_dict() for k, v in self.symbols.items()},
        }
