"""
Module 3: Code Optimization Engine
Implements Constant Folding, Constant Propagation, Copy Propagation,
Dead Code Elimination, Common Sub-expression Elimination, and Strength Reduction.
"""

from typing import List, Dict, Any, Tuple, Optional
from compiler.ir_generator import TACInstruction


def is_number(val: Optional[str]) -> bool:
    if val is None:
        return False
    try:
        float(val)
        return True
    except ValueError:
        return False


def parse_number(val: str) -> Any:
    if "." in val:
        return float(val)
    return int(val)


class Optimizer:
    """Multi-pass optimizer for Three Address Code."""

    def __init__(self):
        self.applied_optimizations: List[Dict[str, str]] = []

    def optimize(self, instructions: List[TACInstruction]) -> Tuple[List[TACInstruction], List[Dict[str, str]], Dict[str, Any]]:
        self.applied_optimizations.clear()
        initial_count = len(instructions)

        current = [TACInstruction(i.op, i.arg1, i.arg2, i.result, i.comment) for i in instructions]

        # Iterative optimization passes until fixed point or max 5 passes
        for pass_num in range(5):
            changed = False

            # 1. Constant folding & propagation
            current, c_changed = self.pass_constant_folding_and_propagation(current)
            changed = changed or c_changed

            # 2. Strength reduction
            current, s_changed = self.pass_strength_reduction(current)
            changed = changed or s_changed

            # 3. Common Subexpression Elimination
            current, cse_changed = self.pass_common_subexpression_elimination(current)
            changed = changed or cse_changed

            # 4. Copy propagation
            current, cp_changed = self.pass_copy_propagation(current)
            changed = changed or cp_changed

            # 5. Dead Code Elimination
            current, dce_changed = self.pass_dead_code_elimination(current)
            changed = changed or dce_changed

            if not changed:
                break

        final_count = len(current)
        reduction = max(0, initial_count - final_count)
        opt_percentage = round((reduction / initial_count * 100.0), 1) if initial_count > 0 else 0.0

        stats = {
            "initial_instructions": initial_count,
            "optimized_instructions": final_count,
            "instructions_reduced": reduction,
            "optimization_percentage": opt_percentage,
            "applied_count": len(self.applied_optimizations),
        }

        return current, self.applied_optimizations, stats

    def pass_constant_folding_and_propagation(self, instrs: List[TACInstruction]) -> Tuple[List[TACInstruction], bool]:
        new_instrs: List[TACInstruction] = []
        constants: Dict[str, Any] = {}
        changed = False

        for instr in instrs:
            # Invalidate constants across labels/branches to be conservative
            if instr.op in ("label", "func_begin", "func_end"):
                constants.clear()
                new_instrs.append(instr)
                continue

            # Replace arguments with known constants if applicable
            arg1 = constants.get(instr.arg1, instr.arg1) if instr.arg1 in constants else instr.arg1
            arg2 = constants.get(instr.arg2, instr.arg2) if instr.arg2 in constants else instr.arg2

            if arg1 != instr.arg1 or arg2 != instr.arg2:
                changed = True
                self.applied_optimizations.append({
                    "pass": "Constant Propagation",
                    "details": f"Propagated constant: replaced args in '{instr}' -> arg1={arg1}, arg2={arg2}"
                })

            # Check if binary operation has two numeric constants
            if instr.op in ("+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">="):
                if is_number(arg1) and is_number(arg2):
                    n1 = parse_number(str(arg1))
                    n2 = parse_number(str(arg2))
                    computed = None

                    try:
                        if instr.op == "+": computed = n1 + n2
                        elif instr.op == "-": computed = n1 - n2
                        elif instr.op == "*": computed = n1 * n2
                        elif instr.op == "/": computed = n1 // n2 if isinstance(n1, int) and isinstance(n2, int) and n2 != 0 else (n1 / n2 if n2 != 0 else 0)
                        elif instr.op == "%": computed = n1 % n2 if n2 != 0 else 0
                        elif instr.op == "==": computed = 1 if n1 == n2 else 0
                        elif instr.op == "!=": computed = 1 if n1 != n2 else 0
                        elif instr.op == "<": computed = 1 if n1 < n2 else 0
                        elif instr.op == "<=": computed = 1 if n1 <= n2 else 0
                        elif instr.op == ">": computed = 1 if n1 > n2 else 0
                        elif instr.op == ">=": computed = 1 if n1 >= n2 else 0
                    except ZeroDivisionError:
                        computed = 0

                    if computed is not None:
                        val_str = str(computed)
                        folded_instr = TACInstruction(op="=", arg1=val_str, result=instr.result)
                        new_instrs.append(folded_instr)
                        if instr.result:
                            constants[instr.result] = val_str
                        changed = True
                        self.applied_optimizations.append({
                            "pass": "Constant Folding",
                            "details": f"Evaluated '{arg1} {instr.op} {arg2}' to compile-time constant '{val_str}'"
                        })
                        continue

            # Check unary negation on constant
            if instr.op == "neg" and is_number(arg1):
                val_str = str(-parse_number(str(arg1)))
                folded_instr = TACInstruction(op="=", arg1=val_str, result=instr.result)
                new_instrs.append(folded_instr)
                if instr.result:
                    constants[instr.result] = val_str
                changed = True
                self.applied_optimizations.append({
                    "pass": "Constant Folding",
                    "details": f"Evaluated 'neg {arg1}' to '{val_str}'"
                })
                continue

            # Direct assignment: result = const
            if instr.op == "=" and is_number(arg1):
                if instr.result:
                    constants[instr.result] = str(arg1)
            elif instr.result in constants:
                del constants[instr.result]

            new_instrs.append(TACInstruction(instr.op, arg1, arg2, instr.result, instr.comment))

        return new_instrs, changed

    def pass_strength_reduction(self, instrs: List[TACInstruction]) -> Tuple[List[TACInstruction], bool]:
        new_instrs: List[TACInstruction] = []
        changed = False

        for instr in instrs:
            # x * 2 -> x + x
            if instr.op == "*":
                if instr.arg2 == "2":
                    new_instr = TACInstruction(op="+", arg1=instr.arg1, arg2=instr.arg1, result=instr.result)
                    new_instrs.append(new_instr)
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Strength Reduction",
                        "details": f"Replaced '{instr.arg1} * 2' with addition '{instr.arg1} + {instr.arg1}'"
                    })
                    continue
                elif instr.arg1 == "2":
                    new_instr = TACInstruction(op="+", arg1=instr.arg2, arg2=instr.arg2, result=instr.result)
                    new_instrs.append(new_instr)
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Strength Reduction",
                        "details": f"Replaced '2 * {instr.arg2}' with addition '{instr.arg2} + {instr.arg2}'"
                    })
                    continue
                # x * 0 -> 0
                elif instr.arg2 == "0" or instr.arg1 == "0":
                    new_instr = TACInstruction(op="=", arg1="0", result=instr.result)
                    new_instrs.append(new_instr)
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Strength Reduction",
                        "details": f"Multiplication by zero simplified to '0'"
                    })
                    continue
                # x * 1 -> x
                elif instr.arg2 == "1":
                    new_instr = TACInstruction(op="=", arg1=instr.arg1, result=instr.result)
                    new_instrs.append(new_instr)
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Strength Reduction",
                        "details": f"Multiplication by 1 simplified to '{instr.arg1}'"
                    })
                    continue
                elif instr.arg1 == "1":
                    new_instr = TACInstruction(op="=", arg1=instr.arg2, result=instr.result)
                    new_instrs.append(new_instr)
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Strength Reduction",
                        "details": f"Multiplication by 1 simplified to '{instr.arg2}'"
                    })
                    continue

            # x + 0 -> x
            if instr.op == "+":
                if instr.arg2 == "0":
                    new_instrs.append(TACInstruction(op="=", arg1=instr.arg1, result=instr.result))
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Algebraic Simplification",
                        "details": f"Identity addition '{instr.arg1} + 0' simplified to '{instr.arg1}'"
                    })
                    continue
                elif instr.arg1 == "0":
                    new_instrs.append(TACInstruction(op="=", arg1=instr.arg2, result=instr.result))
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Algebraic Simplification",
                        "details": f"Identity addition '0 + {instr.arg2}' simplified to '{instr.arg2}'"
                    })
                    continue

            # x - 0 -> x
            if instr.op == "-" and instr.arg2 == "0":
                new_instrs.append(TACInstruction(op="=", arg1=instr.arg1, result=instr.result))
                changed = True
                self.applied_optimizations.append({
                    "pass": "Algebraic Simplification",
                    "details": f"Identity subtraction '{instr.arg1} - 0' simplified to '{instr.arg1}'"
                })
                continue

            new_instrs.append(instr)

        return new_instrs, changed

    def pass_common_subexpression_elimination(self, instrs: List[TACInstruction]) -> Tuple[List[TACInstruction], bool]:
        new_instrs: List[TACInstruction] = []
        expr_map: Dict[Tuple[str, str, str], str] = {}
        changed = False

        for instr in instrs:
            if instr.op in ("label", "func_begin", "func_end", "goto", "if_false_goto"):
                expr_map.clear()
                new_instrs.append(instr)
                continue

            if instr.op in ("+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">="):
                key = (instr.op, str(instr.arg1), str(instr.arg2))
                # For commutative operators +, *, also check reversed
                rev_key = (instr.op, str(instr.arg2), str(instr.arg1)) if instr.op in ("+", "*", "==", "!=") else None

                existing_temp = expr_map.get(key) or (expr_map.get(rev_key) if rev_key else None)
                if existing_temp:
                    # Common subexpression found!
                    new_instr = TACInstruction(op="=", arg1=existing_temp, result=instr.result)
                    new_instrs.append(new_instr)
                    changed = True
                    self.applied_optimizations.append({
                        "pass": "Common Subexpression Elimination",
                        "details": f"Reused existing computation '{existing_temp}' for '{instr.arg1} {instr.op} {instr.arg2}'"
                    })
                    continue
                else:
                    if instr.result:
                        expr_map[key] = instr.result

            # Invalidate expressions if operands are redefined
            if instr.result:
                keys_to_del = [k for k in expr_map if k[1] == instr.result or k[2] == instr.result]
                for k in keys_to_del:
                    del expr_map[k]

            new_instrs.append(instr)

        return new_instrs, changed

    def pass_copy_propagation(self, instrs: List[TACInstruction]) -> Tuple[List[TACInstruction], bool]:
        new_instrs: List[TACInstruction] = []
        copies: Dict[str, str] = {}
        changed = False

        for instr in instrs:
            if instr.op in ("label", "func_begin", "func_end", "goto", "if_false_goto"):
                copies.clear()
                new_instrs.append(instr)
                continue

            arg1 = copies.get(instr.arg1, instr.arg1) if instr.arg1 in copies else instr.arg1
            arg2 = copies.get(instr.arg2, instr.arg2) if instr.arg2 in copies else instr.arg2

            if arg1 != instr.arg1 or arg2 != instr.arg2:
                changed = True
                self.applied_optimizations.append({
                    "pass": "Copy Propagation",
                    "details": f"Replaced copy alias: '{instr.arg1}' -> '{arg1}', '{instr.arg2}' -> '{arg2}'"
                })

            # Check if this instruction creates a copy: t2 = t1
            if instr.op == "=" and instr.arg1 and instr.result:
                if not is_number(instr.arg1) and not instr.arg1.startswith('"'):
                    copies[instr.result] = arg1

            # Invalidate any copies involving the modified result
            if instr.result:
                if instr.result in copies:
                    del copies[instr.result]
                keys_to_del = [k for k, v in copies.items() if v == instr.result]
                for k in keys_to_del:
                    del copies[k]

            new_instrs.append(TACInstruction(instr.op, arg1, arg2, instr.result, instr.comment))

        return new_instrs, changed

    def pass_dead_code_elimination(self, instrs: List[TACInstruction]) -> Tuple[List[TACInstruction], bool]:
        # Count variable usages
        used_vars = set()
        for instr in instrs:
            if instr.arg1:
                used_vars.add(instr.arg1)
            if instr.arg2:
                used_vars.add(instr.arg2)
            if instr.op in ("print", "println", "return", "if_false_goto"):
                if instr.arg1:
                    used_vars.add(instr.arg1)
            if instr.op in ("label", "goto", "if_false_goto"):
                if instr.result:
                    used_vars.add(instr.result)

        new_instrs: List[TACInstruction] = []
        changed = False

        for instr in instrs:
            # Temporary variable assignment that is never used later
            # (e.g. t1 = 30 where t1 is never read anywhere because copy/const propagation replaced it)
            if instr.result and instr.result.startswith("t") and instr.result not in used_vars:
                changed = True
                self.applied_optimizations.append({
                    "pass": "Dead Code Elimination",
                    "details": f"Removed unused temporary assignment '{instr.result} = {instr.arg1}'"
                })
                continue

            new_instrs.append(instr)

        return new_instrs, changed
