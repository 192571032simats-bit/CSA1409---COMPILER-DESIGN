"""
Module 4: Runtime Execution Engine and Target VM
Executes Three Address Code instructions directly, capturing runtime output and resource usage.
Also provides native compilation fallback via g++ if desired.
"""

import time
import subprocess
import tempfile
import os
from typing import List, Dict, Any, Tuple, Optional
from compiler.ir_generator import TACInstruction
from compiler.optimizer import is_number, parse_number


class TACVirtualMachine:
    """Fast execution virtual machine for Three Address Code."""

    def __init__(self, max_cycles: int = 100000):
        self.memory: Dict[str, Any] = {}
        self.labels: Dict[str, int] = {}
        self.output_buffer: List[str] = []
        self.max_cycles = max_cycles
        self.pc = 0

    def load(self, instructions: List[TACInstruction]):
        self.instructions = instructions
        self.labels.clear()
        self.memory.clear()
        self.output_buffer.clear()
        self.pc = 0

        # Pass 1: Index labels
        for idx, instr in enumerate(instructions):
            if instr.op == "label" and instr.result:
                self.labels[instr.result] = idx

    def eval_value(self, operand: Optional[str]) -> Any:
        if operand is None:
            return 0
        if is_number(operand):
            return parse_number(operand)
        if operand.startswith('"') and operand.endswith('"'):
            # Process escape sequences
            return operand[1:-1].replace("\\n", "\n").replace("\\t", "\t")
        if operand.startswith("'") and operand.endswith("'"):
            return operand[1:-1]
        return self.memory.get(operand, 0)

    def run(self) -> Tuple[str, int, int]:
        """
        Executes instructions.
        Returns: (output_text, exit_code, cycles_executed)
        """
        cycles = 0
        n_instr = len(self.instructions)

        while self.pc < n_instr and cycles < self.max_cycles:
            cycles += 1
            instr = self.instructions[self.pc]
            op = instr.op

            if op in ("label", "func_begin", "func_end"):
                self.pc += 1
                continue

            elif op == "=":
                val = self.eval_value(instr.arg1)
                if instr.result:
                    self.memory[instr.result] = val
                self.pc += 1

            elif op in ("+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">="):
                v1 = self.eval_value(instr.arg1)
                v2 = self.eval_value(instr.arg2)
                res = 0
                try:
                    if op == "+": res = v1 + v2
                    elif op == "-": res = v1 - v2
                    elif op == "*": res = v1 * v2
                    elif op == "/": res = v1 // v2 if isinstance(v1, int) and isinstance(v2, int) and v2 != 0 else (v1 / v2 if v2 != 0 else 0)
                    elif op == "%": res = v1 % v2 if v2 != 0 else 0
                    elif op == "==": res = 1 if v1 == v2 else 0
                    elif op == "!=": res = 1 if v1 != v2 else 0
                    elif op == "<": res = 1 if v1 < v2 else 0
                    elif op == "<=": res = 1 if v1 <= v2 else 0
                    elif op == ">": res = 1 if v1 > v2 else 0
                    elif op == ">=": res = 1 if v1 >= v2 else 0
                except ZeroDivisionError:
                    res = 0

                if instr.result:
                    self.memory[instr.result] = res
                self.pc += 1

            elif op == "neg":
                v1 = self.eval_value(instr.arg1)
                if instr.result:
                    self.memory[instr.result] = -v1
                self.pc += 1

            elif op == "not":
                v1 = self.eval_value(instr.arg1)
                if instr.result:
                    self.memory[instr.result] = 0 if v1 else 1
                self.pc += 1

            elif op == "goto":
                target = instr.result
                if target in self.labels:
                    self.pc = self.labels[target]
                else:
                    self.pc += 1

            elif op == "if_false_goto":
                cond = self.eval_value(instr.arg1)
                target = instr.result
                if not cond:
                    if target in self.labels:
                        self.pc = self.labels[target]
                    else:
                        self.pc += 1
                else:
                    self.pc += 1

            elif op == "print":
                val = self.eval_value(instr.arg1)
                self.output_buffer.append(str(val))
                self.pc += 1

            elif op == "println":
                if instr.arg1:
                    val = self.eval_value(instr.arg1)
                    self.output_buffer.append(str(val))
                self.output_buffer.append("\n")
                self.pc += 1

            elif op == "return":
                ret_val = self.eval_value(instr.arg1) if instr.arg1 else 0
                return "".join(self.output_buffer), int(ret_val), cycles

            else:
                self.pc += 1

        if cycles >= self.max_cycles:
            self.output_buffer.append("\n[Runtime Warning: Infinite loop detected or maximum execution limit exceeded.]\n")

        return "".join(self.output_buffer), 0, cycles


def run_with_native_gcc(cpp_code: str, timeout_seconds: int = 4) -> Optional[Dict[str, Any]]:
    """Optionally run code natively using g++ if installed on the machine."""
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            src_file = os.path.join(tmpdir, "program.cpp")
            exe_file = os.path.join(tmpdir, "program.exe")

            with open(src_file, "w", encoding="utf-8") as f:
                f.write(cpp_code)

            # Compile
            comp_res = subprocess.run(
                ["g++", "-O2", src_file, "-o", exe_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_seconds,
                text=True
            )

            if comp_res.returncode != 0:
                return {
                    "success": False,
                    "output": "",
                    "error": comp_res.stderr,
                }

            # Run executable
            start_time = time.perf_counter()
            run_res = subprocess.run(
                [exe_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_seconds,
                text=True
            )
            exec_time_ms = (time.perf_counter() - start_time) * 1000

            return {
                "success": True,
                "output": run_res.stdout,
                "error": run_res.stderr,
                "return_code": run_res.returncode,
                "execution_time_ms": round(exec_time_ms, 2)
            }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": str(e)
        }
