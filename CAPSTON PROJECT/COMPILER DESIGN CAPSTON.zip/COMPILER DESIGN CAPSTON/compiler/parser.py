"""
Module 1: Syntax Analysis and Intelligent Error Recovery Parser
Recursive Descent Parser with Automatic Error Recovery and Diagnostic Reporting.
"""

from typing import List, Dict, Any, Optional, Tuple
from compiler.tokens import Token, TokenType
from compiler.ast_nodes import (
    ASTNode, ProgramNode, PreprocessorNode, UsingNamespaceNode,
    VarDeclNode, AssignNode, BinaryOpNode, UnaryOpNode,
    LiteralNode, VariableNode, BlockNode, IfNode, WhileNode,
    ForNode, ReturnNode, FunctionDeclNode, ParameterNode,
    CoutNode, CinNode, ExpressionStatementNode
)


class Parser:
    """Recursive descent parser with intelligent error recovery."""

    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.diagnostics: List[Dict[str, Any]] = []

    def log_diagnostic(
        self,
        severity: str,
        message: str,
        suggestion: str,
        line: int,
        column: int,
        recovered: bool = True,
        action: str = ""
    ):
        self.diagnostics.append({
            "phase": "Syntax",
            "severity": severity,
            "message": message,
            "suggestion": suggestion,
            "line": line,
            "column": column,
            "recovered": recovered,
            "action": action
        })

    def current_token(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]  # EOF token

    def peek(self, offset: int = 1) -> Token:
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return self.tokens[-1]

    def advance(self) -> Token:
        tok = self.current_token()
        if tok.type != TokenType.EOF:
            self.pos += 1
        return tok

    def match(self, *expected_types: TokenType) -> bool:
        return self.current_token().type in expected_types

    def consume(self, expected_type: TokenType, err_msg: str, suggestion: str) -> Token:
        if self.match(expected_type):
            return self.advance()
        tok = self.current_token()
        self.log_diagnostic(
            severity="Error",
            message=err_msg,
            suggestion=suggestion,
            line=tok.line,
            column=tok.column,
            recovered=True,
            action=f"Auto-inserted virtual {expected_type.value}"
        )
        # Create virtual token for recovery
        return Token(expected_type, expected_type.value, tok.line, tok.column, expected_type.value)

    def consume_semicolon(self, context_desc: str = "statement"):
        tok = self.current_token()
        if self.match(TokenType.SEMICOLON):
            self.advance()
            return

        # Intelligent recovery for missing semicolon
        prev_tok = self.tokens[self.pos - 1] if self.pos > 0 else tok
        self.log_diagnostic(
            severity="Error",
            message=f"Syntax Error: Missing semicolon ';' after {context_desc}.",
            suggestion="Insert ';' at the end of the statement.",
            line=prev_tok.line,
            column=prev_tok.column + len(str(prev_tok.value)),
            recovered=True,
            action="Auto-recovered: Automatically inserted missing semicolon ';' to continue compilation."
        )

    def synchronize_to_statement(self):
        """Skip tokens until a statement boundary (semicolon, brace, or keyword) is found."""
        while not self.match(TokenType.EOF):
            if self.match(TokenType.SEMICOLON):
                self.advance()
                return
            if self.match(
                TokenType.KEYWORD_INT, TokenType.KEYWORD_FLOAT, TokenType.KEYWORD_DOUBLE,
                TokenType.KEYWORD_CHAR, TokenType.KEYWORD_BOOL, TokenType.KEYWORD_VOID,
                TokenType.KEYWORD_IF, TokenType.KEYWORD_WHILE, TokenType.KEYWORD_FOR,
                TokenType.KEYWORD_RETURN, TokenType.KEYWORD_COUT, TokenType.KEYWORD_CIN,
                TokenType.RBRACE
            ):
                return
            self.advance()

    def parse(self) -> Tuple[ProgramNode, List[Dict[str, Any]]]:
        """Main entry point: parses translation unit."""
        declarations = []
        while not self.match(TokenType.EOF):
            decl = self.parse_top_level_declaration()
            if decl:
                declarations.append(decl)
            else:
                self.synchronize_to_statement()

        return ProgramNode(declarations=declarations), self.diagnostics

    def parse_top_level_declaration(self) -> Optional[ASTNode]:
        tok = self.current_token()

        # Preprocessor directive: #include <iostream>
        if self.match(TokenType.PREPROCESSOR):
            self.advance()
            return PreprocessorNode(directive=str(tok.value), line=tok.line, column=tok.column)

        # using namespace std;
        if self.match(TokenType.KEYWORD_USING):
            self.advance()
            if self.match(TokenType.KEYWORD_NAMESPACE):
                self.advance()
            ns_name = "std"
            if self.match(TokenType.KEYWORD_STD, TokenType.IDENTIFIER):
                ns_name = str(self.advance().value)
            self.consume_semicolon("using namespace directive")
            return UsingNamespaceNode(namespace=ns_name, line=tok.line, column=tok.column)

        # Type specifier -> could be function or global variable
        if self.match(
            TokenType.KEYWORD_INT, TokenType.KEYWORD_FLOAT, TokenType.KEYWORD_DOUBLE,
            TokenType.KEYWORD_CHAR, TokenType.KEYWORD_BOOL, TokenType.KEYWORD_VOID
        ):
            type_tok = self.advance()
            var_type = str(type_tok.value)

            ident_tok = self.consume(
                TokenType.IDENTIFIER,
                "Expected identifier after type specification.",
                "Provide a valid name for the function or variable."
            )

            # Check if function: followed by '('
            if self.match(TokenType.LPAREN):
                return self.parse_function_declaration(var_type, str(ident_tok.value), type_tok.line, type_tok.column)
            else:
                # Global variable
                init_expr = None
                if self.match(TokenType.OP_ASSIGN):
                    self.advance()
                    init_expr = self.parse_expression()
                self.consume_semicolon("variable declaration")
                return VarDeclNode(
                    var_type=var_type,
                    name=str(ident_tok.value),
                    initializer=init_expr,
                    line=type_tok.line,
                    column=type_tok.column
                )

        # Unrecognized top-level token
        self.log_diagnostic(
            severity="Error",
            message=f"Unexpected token '{tok.value}' at top-level.",
            suggestion="Expected preprocessor directive, function, or variable declaration.",
            line=tok.line,
            column=tok.column,
            recovered=True,
            action="Skipped unexpected token and continued."
        )
        self.advance()
        return None

    def parse_function_declaration(
        self,
        return_type: str,
        name: str,
        line: int,
        column: int
    ) -> FunctionDeclNode:
        self.consume(TokenType.LPAREN, "Expected '(' after function name.", "Add '(' before parameter list.")
        params = []
        if not self.match(TokenType.RPAREN):
            while True:
                if self.match(
                    TokenType.KEYWORD_INT, TokenType.KEYWORD_FLOAT, TokenType.KEYWORD_DOUBLE,
                    TokenType.KEYWORD_CHAR, TokenType.KEYWORD_BOOL
                ):
                    p_type = str(self.advance().value)
                    p_name = ""
                    if self.match(TokenType.IDENTIFIER):
                        p_name = str(self.advance().value)
                    params.append(ParameterNode(param_type=p_type, name=p_name, line=self.current_token().line))
                if self.match(TokenType.COMMA):
                    self.advance()
                else:
                    break

        self.consume(TokenType.RPAREN, "Expected ')' after parameter list.", "Add closing ')' after parameters.")

        # Function body
        body = None
        if self.match(TokenType.LBRACE):
            body = self.parse_block()
        else:
            self.consume_semicolon("function declaration")

        return FunctionDeclNode(
            return_type=return_type,
            name=name,
            params=params,
            body=body,
            line=line,
            column=column
        )

    def parse_block(self) -> BlockNode:
        tok = self.consume(TokenType.LBRACE, "Expected '{' to start block.", "Add opening '{'.")
        statements = []

        while not self.match(TokenType.RBRACE) and not self.match(TokenType.EOF):
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            else:
                self.synchronize_to_statement()

        if self.match(TokenType.RBRACE):
            self.advance()
        else:
            self.log_diagnostic(
                severity="Error",
                message="Syntax Error: Missing closing brace '}' for block.",
                suggestion="Insert '}' to close the function or block.",
                line=self.current_token().line,
                column=self.current_token().column,
                recovered=True,
                action="Auto-recovered: Automatically inserted closing brace '}' at end of scope."
            )

        return BlockNode(statements=statements, line=tok.line, column=tok.column)

    def parse_statement(self) -> Optional[ASTNode]:
        tok = self.current_token()

        # Variable declaration
        if self.match(
            TokenType.KEYWORD_INT, TokenType.KEYWORD_FLOAT, TokenType.KEYWORD_DOUBLE,
            TokenType.KEYWORD_CHAR, TokenType.KEYWORD_BOOL
        ):
            v_type = str(self.advance().value)
            v_name_tok = self.consume(
                TokenType.IDENTIFIER,
                "Expected variable name after type specifier.",
                "Specify a valid identifier name."
            )
            v_name = str(v_name_tok.value)
            init_expr = None
            if self.match(TokenType.OP_ASSIGN):
                self.advance()
                init_expr = self.parse_expression()
            self.consume_semicolon(f"variable declaration for '{v_name}'")
            return VarDeclNode(
                var_type=v_type,
                name=v_name,
                initializer=init_expr,
                line=tok.line,
                column=tok.column
            )

        # cout << ...
        if self.match(TokenType.KEYWORD_COUT):
            return self.parse_cout()

        # cin >> ...
        if self.match(TokenType.KEYWORD_CIN):
            return self.parse_cin()

        # if statement
        if self.match(TokenType.KEYWORD_IF):
            return self.parse_if()

        # while statement
        if self.match(TokenType.KEYWORD_WHILE):
            return self.parse_while()

        # for statement
        if self.match(TokenType.KEYWORD_FOR):
            return self.parse_for()

        # return statement
        if self.match(TokenType.KEYWORD_RETURN):
            self.advance()
            expr = None
            if not self.match(TokenType.SEMICOLON):
                expr = self.parse_expression()
            self.consume_semicolon("return statement")
            return ReturnNode(value=expr, line=tok.line, column=tok.column)

        # Nested block
        if self.match(TokenType.LBRACE):
            return self.parse_block()

        # Empty statement
        if self.match(TokenType.SEMICOLON):
            self.advance()
            return None

        # Expression statement (assignments, increments, calls)
        expr = self.parse_expression()
        self.consume_semicolon("expression statement")
        return ExpressionStatementNode(expr=expr, line=tok.line, column=tok.column)

    def parse_cout(self) -> CoutNode:
        tok = self.advance()  # consume 'cout'
        args = []

        while self.match(TokenType.OP_LSHIFT):
            self.advance()  # consume '<<'
            if self.match(TokenType.KEYWORD_ENDL):
                endl_tok = self.advance()
                args.append(LiteralNode(value="\n", literal_type="string", line=endl_tok.line, column=endl_tok.column))
            else:
                arg = self.parse_expression()
                if arg:
                    args.append(arg)

        # Intelligent recovery: if user typed "cout << "Sum = " sum" missing '<<'
        if not args and not self.match(TokenType.SEMICOLON):
            self.log_diagnostic(
                severity="Error",
                message="Syntax Error: Expected '<<' after cout.",
                suggestion="Use 'cout << <expression>;'.",
                line=tok.line,
                column=tok.column,
                recovered=True,
                action="Attempting to recover stream arguments"
            )
            arg = self.parse_expression()
            if arg:
                args.append(arg)

        self.consume_semicolon("cout statement")
        return CoutNode(args=args, line=tok.line, column=tok.column)

    def parse_cin(self) -> CinNode:
        tok = self.advance()  # consume 'cin'
        targets = []
        while self.match(TokenType.OP_RSHIFT):
            self.advance()
            if self.match(TokenType.IDENTIFIER):
                targets.append(str(self.advance().value))
            else:
                self.log_diagnostic(
                    severity="Error",
                    message="Expected identifier after '>>' in cin.",
                    suggestion="Specify variable to read into.",
                    line=tok.line,
                    column=tok.column,
                    recovered=True,
                    action="Skipping invalid cin target"
                )
        self.consume_semicolon("cin statement")
        return CinNode(targets=targets, line=tok.line, column=tok.column)

    def parse_if(self) -> IfNode:
        tok = self.advance()  # consume 'if'
        self.consume(TokenType.LPAREN, "Expected '(' after 'if'.", "Enclose condition in parentheses: if (...)")
        cond = self.parse_expression()
        self.consume(TokenType.RPAREN, "Expected ')' after condition in 'if'.", "Close condition with ')'.")

        then_branch = self.parse_statement_or_block()
        else_branch = None
        if self.match(TokenType.KEYWORD_ELSE):
            self.advance()
            else_branch = self.parse_statement_or_block()

        return IfNode(condition=cond, then_branch=then_branch, else_branch=else_branch, line=tok.line, column=tok.column)

    def parse_while(self) -> WhileNode:
        tok = self.advance()  # consume 'while'
        self.consume(TokenType.LPAREN, "Expected '(' after 'while'.", "Enclose condition in parentheses: while (...)")
        cond = self.parse_expression()
        self.consume(TokenType.RPAREN, "Expected ')' after condition in 'while'.", "Close condition with ')'.")
        body = self.parse_statement_or_block()
        return WhileNode(condition=cond, body=body, line=tok.line, column=tok.column)

    def parse_for(self) -> ForNode:
        tok = self.advance()  # consume 'for'
        self.consume(TokenType.LPAREN, "Expected '(' after 'for'.", "Provide '(init; cond; step)'.")

        # Init
        init = None
        if not self.match(TokenType.SEMICOLON):
            if self.match(TokenType.KEYWORD_INT):
                self.advance()
                name_tok = self.consume(TokenType.IDENTIFIER, "Expected identifier in for init", "Provide loop variable")
                init_val = None
                if self.match(TokenType.OP_ASSIGN):
                    self.advance()
                    init_val = self.parse_expression()
                init = VarDeclNode(var_type="int", name=str(name_tok.value), initializer=init_val, line=tok.line, column=tok.column)
            else:
                init = self.parse_expression()
        self.consume_semicolon("for-loop initialization")

        # Condition
        cond = None
        if not self.match(TokenType.SEMICOLON):
            cond = self.parse_expression()
        self.consume_semicolon("for-loop condition")

        # Update / step
        update = None
        if not self.match(TokenType.RPAREN):
            update = self.parse_expression()
        self.consume(TokenType.RPAREN, "Expected ')' after for clauses.", "Close for-loop header with ')'.")

        body = self.parse_statement_or_block()
        return ForNode(init=init, condition=cond, update=update, body=body, line=tok.line, column=tok.column)

    def parse_statement_or_block(self) -> ASTNode:
        if self.match(TokenType.LBRACE):
            return self.parse_block()
        return self.parse_statement() or BlockNode()

    # Expression parsing (Precedence Climbing)
    def parse_expression(self) -> Optional[ASTNode]:
        return self.parse_assignment()

    def parse_assignment(self) -> Optional[ASTNode]:
        # Lookahead: is this `identifier = expr`?
        if self.match(TokenType.IDENTIFIER) and self.peek().type in (
            TokenType.OP_ASSIGN,
        ):
            target_tok = self.advance()
            op_tok = self.advance()
            val = self.parse_assignment()
            return AssignNode(
                name=str(target_tok.value),
                op=str(op_tok.value),
                value=val,
                line=target_tok.line,
                column=target_tok.column
            )
        return self.parse_logical_or()

    def parse_logical_or(self) -> Optional[ASTNode]:
        left = self.parse_logical_and()
        while self.match(TokenType.OP_OR):
            op = self.advance().value
            right = self.parse_logical_and()
            left = BinaryOpNode(op=str(op), left=left, right=right, line=left.line if left else 1)
        return left

    def parse_logical_and(self) -> Optional[ASTNode]:
        left = self.parse_equality()
        while self.match(TokenType.OP_AND):
            op = self.advance().value
            right = self.parse_equality()
            left = BinaryOpNode(op=str(op), left=left, right=right, line=left.line if left else 1)
        return left

    def parse_equality(self) -> Optional[ASTNode]:
        left = self.parse_relational()
        while self.match(TokenType.OP_EQ, TokenType.OP_NE):
            op = self.advance().value
            right = self.parse_relational()
            left = BinaryOpNode(op=str(op), left=left, right=right, line=left.line if left else 1)
        return left

    def parse_relational(self) -> Optional[ASTNode]:
        left = self.parse_additive()
        while self.match(TokenType.OP_LT, TokenType.OP_LE, TokenType.OP_GT, TokenType.OP_GE):
            op = self.advance().value
            right = self.parse_additive()
            left = BinaryOpNode(op=str(op), left=left, right=right, line=left.line if left else 1)
        return left

    def parse_additive(self) -> Optional[ASTNode]:
        left = self.parse_multiplicative()
        while self.match(TokenType.OP_PLUS, TokenType.OP_MINUS):
            op = self.advance().value
            right = self.parse_multiplicative()
            left = BinaryOpNode(op=str(op), left=left, right=right, line=left.line if left else 1)
        return left

    def parse_multiplicative(self) -> Optional[ASTNode]:
        left = self.parse_unary()
        while self.match(TokenType.OP_MUL, TokenType.OP_DIV, TokenType.OP_MOD):
            op = self.advance().value
            right = self.parse_unary()
            left = BinaryOpNode(op=str(op), left=left, right=right, line=left.line if left else 1)
        return left

    def parse_unary(self) -> Optional[ASTNode]:
        tok = self.current_token()
        if self.match(TokenType.OP_NOT, TokenType.OP_MINUS, TokenType.OP_PLUS):
            op = self.advance().value
            expr = self.parse_unary()
            return UnaryOpNode(op=str(op), expr=expr, is_postfix=False, line=tok.line, column=tok.column)
        return self.parse_postfix()

    def parse_postfix(self) -> Optional[ASTNode]:
        node = self.parse_primary()
        if self.match(TokenType.OP_INC, TokenType.OP_DEC):
            op = self.advance().value
            node = UnaryOpNode(op=str(op), expr=node, is_postfix=True, line=node.line if node else 1)
        return node

    def parse_primary(self) -> Optional[ASTNode]:
        tok = self.current_token()

        if self.match(TokenType.INT_LITERAL):
            self.advance()
            return LiteralNode(value=int(tok.value), literal_type="int", line=tok.line, column=tok.column)

        if self.match(TokenType.FLOAT_LITERAL):
            self.advance()
            return LiteralNode(value=float(tok.value), literal_type="float", line=tok.line, column=tok.column)

        if self.match(TokenType.STRING_LITERAL):
            self.advance()
            return LiteralNode(value=str(tok.value), literal_type="string", line=tok.line, column=tok.column)

        if self.match(TokenType.CHAR_LITERAL):
            self.advance()
            return LiteralNode(value=str(tok.value), literal_type="char", line=tok.line, column=tok.column)

        if self.match(TokenType.BOOL_LITERAL):
            self.advance()
            val = True if tok.value == "true" else False
            return LiteralNode(value=val, literal_type="bool", line=tok.line, column=tok.column)

        if self.match(TokenType.IDENTIFIER):
            self.advance()
            return VariableNode(name=str(tok.value), line=tok.line, column=tok.column)

        if self.match(TokenType.LPAREN):
            self.advance()
            expr = self.parse_expression()
            self.consume(TokenType.RPAREN, "Expected ')' to close grouped expression.", "Add closing ')'.")
            return expr

        # Fallback for unexpected token in expression
        self.log_diagnostic(
            severity="Error",
            message=f"Syntax Error: Unexpected token '{tok.value}' in expression.",
            suggestion="Expected a number, variable, or open parenthesis.",
            line=tok.line,
            column=tok.column,
            recovered=True,
            action="Substituted fallback 0 literal"
        )
        self.advance()
        return LiteralNode(value=0, literal_type="int", line=tok.line, column=tok.column)
