"""
Abstract Syntax Tree (AST) node definitions for C++ subset
"""

from typing import List, Optional, Any
from dataclasses import dataclass, field


@dataclass(kw_only=True)
class ASTNode:
    line: int = 1
    column: int = 1

    def to_dict(self) -> dict:
        d = {"node_type": self.__class__.__name__}
        for k, v in self.__dict__.items():
            if isinstance(v, ASTNode):
                d[k] = v.to_dict()
            elif isinstance(v, list):
                d[k] = [item.to_dict() if isinstance(item, ASTNode) else item for item in v]
            else:
                d[k] = v
        return d


@dataclass(kw_only=True)
class ProgramNode(ASTNode):
    declarations: List[ASTNode] = field(default_factory=list)


@dataclass(kw_only=True)
class PreprocessorNode(ASTNode):
    directive: str = ""


@dataclass(kw_only=True)
class UsingNamespaceNode(ASTNode):
    namespace: str = "std"


@dataclass(kw_only=True)
class VarDeclNode(ASTNode):
    var_type: str = "int"
    name: str = ""
    initializer: Optional[ASTNode] = None


@dataclass(kw_only=True)
class AssignNode(ASTNode):
    name: str = ""
    op: str = "="
    value: Optional[ASTNode] = None


@dataclass(kw_only=True)
class BinaryOpNode(ASTNode):
    op: str = "+"
    left: Optional[ASTNode] = None
    right: Optional[ASTNode] = None


@dataclass(kw_only=True)
class UnaryOpNode(ASTNode):
    op: str = "-"
    expr: Optional[ASTNode] = None
    is_postfix: bool = False


@dataclass(kw_only=True)
class LiteralNode(ASTNode):
    value: Any = None
    literal_type: str = "int"


@dataclass(kw_only=True)
class VariableNode(ASTNode):
    name: str = ""


@dataclass(kw_only=True)
class BlockNode(ASTNode):
    statements: List[ASTNode] = field(default_factory=list)


@dataclass(kw_only=True)
class IfNode(ASTNode):
    condition: Optional[ASTNode] = None
    then_branch: Optional[ASTNode] = None
    else_branch: Optional[ASTNode] = None


@dataclass(kw_only=True)
class WhileNode(ASTNode):
    condition: Optional[ASTNode] = None
    body: Optional[ASTNode] = None


@dataclass(kw_only=True)
class ForNode(ASTNode):
    init: Optional[ASTNode] = None
    condition: Optional[ASTNode] = None
    update: Optional[ASTNode] = None
    body: Optional[ASTNode] = None


@dataclass(kw_only=True)
class ReturnNode(ASTNode):
    value: Optional[ASTNode] = None


@dataclass(kw_only=True)
class ParameterNode(ASTNode):
    param_type: str = "int"
    name: str = ""


@dataclass(kw_only=True)
class FunctionDeclNode(ASTNode):
    return_type: str = "int"
    name: str = "main"
    params: List[ParameterNode] = field(default_factory=list)
    body: Optional[BlockNode] = None


@dataclass(kw_only=True)
class CoutNode(ASTNode):
    args: List[ASTNode] = field(default_factory=list)


@dataclass(kw_only=True)
class CinNode(ASTNode):
    targets: List[str] = field(default_factory=list)


@dataclass(kw_only=True)
class ExpressionStatementNode(ASTNode):
    expr: Optional[ASTNode] = None
