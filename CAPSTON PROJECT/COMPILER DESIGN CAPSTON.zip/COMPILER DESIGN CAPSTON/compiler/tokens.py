"""
Tokens definition for the Intelligent C++ Compiler
Module 1: Lexical and Syntax Analysis Support
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Any, Optional


class TokenType(Enum):
    # Keywords
    KEYWORD_INT = "int"
    KEYWORD_FLOAT = "float"
    KEYWORD_DOUBLE = "double"
    KEYWORD_CHAR = "char"
    KEYWORD_BOOL = "bool"
    KEYWORD_VOID = "void"
    KEYWORD_RETURN = "return"
    KEYWORD_IF = "if"
    KEYWORD_ELSE = "else"
    KEYWORD_WHILE = "while"
    KEYWORD_FOR = "for"
    KEYWORD_COUT = "cout"
    KEYWORD_CIN = "cin"
    KEYWORD_ENDL = "endl"
    KEYWORD_USING = "using"
    KEYWORD_NAMESPACE = "namespace"
    KEYWORD_STD = "std"
    KEYWORD_INCLUDE = "include"

    # Literals
    INT_LITERAL = "INT_LITERAL"
    FLOAT_LITERAL = "FLOAT_LITERAL"
    STRING_LITERAL = "STRING_LITERAL"
    CHAR_LITERAL = "CHAR_LITERAL"
    BOOL_LITERAL = "BOOL_LITERAL"

    # Identifiers
    IDENTIFIER = "IDENTIFIER"

    # Operators
    OP_ASSIGN = "="
    OP_PLUS = "+"
    OP_MINUS = "-"
    OP_MUL = "*"
    OP_DIV = "/"
    OP_MOD = "%"
    OP_EQ = "=="
    OP_NE = "!="
    OP_LT = "<"
    OP_LE = "<="
    OP_GT = ">"
    OP_GE = ">="
    OP_LSHIFT = "<<"
    OP_RSHIFT = ">>"
    OP_AND = "&&"
    OP_OR = "||"
    OP_NOT = "!"
    OP_INC = "++"
    OP_DEC = "--"

    # Delimiters
    SEMICOLON = ";"
    COMMA = ","
    LPAREN = "("
    RPAREN = ")"
    LBRACE = "{"
    RBRACE = "}"
    LBRACKET = "["
    RBRACKET = "]"
    HASH = "#"

    # Special / Error / Stream
    PREPROCESSOR = "PREPROCESSOR"
    EOF = "EOF"
    UNKNOWN = "UNKNOWN"


KEYWORDS = {
    "int": TokenType.KEYWORD_INT,
    "float": TokenType.KEYWORD_FLOAT,
    "double": TokenType.KEYWORD_DOUBLE,
    "char": TokenType.KEYWORD_CHAR,
    "bool": TokenType.KEYWORD_BOOL,
    "void": TokenType.KEYWORD_VOID,
    "return": TokenType.KEYWORD_RETURN,
    "if": TokenType.KEYWORD_IF,
    "else": TokenType.KEYWORD_ELSE,
    "while": TokenType.KEYWORD_WHILE,
    "for": TokenType.KEYWORD_FOR,
    "cout": TokenType.KEYWORD_COUT,
    "cin": TokenType.KEYWORD_CIN,
    "endl": TokenType.KEYWORD_ENDL,
    "using": TokenType.KEYWORD_USING,
    "namespace": TokenType.KEYWORD_NAMESPACE,
    "std": TokenType.KEYWORD_STD,
    "include": TokenType.KEYWORD_INCLUDE,
    "true": TokenType.BOOL_LITERAL,
    "false": TokenType.BOOL_LITERAL,
}


@dataclass
class Token:
    type: TokenType
    value: Any
    line: int
    column: int
    raw: str = ""

    def to_dict(self):
        return {
            "type": self.type.name,
            "value": str(self.value),
            "line": self.line,
            "column": self.column,
            "raw": self.raw or str(self.value),
        }

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, Line:{self.line}:{self.column})"
