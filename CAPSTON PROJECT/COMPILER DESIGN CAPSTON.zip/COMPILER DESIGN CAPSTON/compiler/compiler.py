"""
Intelligent Compiler Pipeline Coordinator
Orchestrates Modules 1 through 5 as defined in the System Architecture.
"""

from typing import Dict, Any, List
from compiler.tokens import Token
from compiler.lexer import Lexer
from compiler.parser import Parser
from compiler.semantic import SemanticAnalyzer
from compiler.ir_generator import IRGenerator
from compiler.optimizer import Optimizer
from compiler.codegen import TargetCodeGenerator
from compiler.runtime import TACVirtualMachine, run_with_native_gcc
from compiler.profiler import PerformanceProfiler


class IntelligentCompiler:
    """End-to-End Intelligent Compiler Engine."""

    def __init__(self):
        self.profiler = PerformanceProfiler()

    def compile_and_run(self, source_code: str, use_native_gcc: bool = False) -> Dict[str, Any]:
        """
        Runs the complete 5-stage compilation pipeline:
        1. Lexical Analysis
        2. Syntax Analysis
        3. Semantic Analysis & Intelligent Recovery
        4. Intermediate Code Generation & Optimization
        5. Target Code Generation & Runtime Execution + Profiling
        """
        all_diagnostics: List[Dict[str, Any]] = []

        # =========================================================
        # Module 1: Lexical Analysis
        # =========================================================
        self.profiler.start_compilation()

        lexer = Lexer(source_code)
        tokens, lex_diagnostics = lexer.tokenize()
        all_diagnostics.extend(lex_diagnostics)

        # =========================================================
        # Module 1: Syntax Analysis
        # =========================================================
        parser = Parser(tokens)
        ast, syn_diagnostics = parser.parse()
        all_diagnostics.extend(syn_diagnostics)

        # =========================================================
        # Module 2: Semantic Analysis & Intelligent Error Recovery
        # =========================================================
        semantic_analyzer = SemanticAnalyzer()
        ast, symbol_table, sem_diagnostics = semantic_analyzer.analyze(ast)
        all_diagnostics.extend(sem_diagnostics)

        # =========================================================
        # Module 3: Intermediate Code Generation (TAC)
        # =========================================================
        ir_generator = IRGenerator()
        raw_tac = ir_generator.generate(ast)

        # =========================================================
        # Module 3: Code Optimization
        # =========================================================
        optimizer = Optimizer()
        optimized_tac, applied_opts, opt_stats = optimizer.optimize(raw_tac)

        # =========================================================
        # Module 4: Target Code Generation (x86-64 Assembly)
        # =========================================================
        codegen = TargetCodeGenerator()
        assembly_code = codegen.generate(optimized_tac)

        self.profiler.end_compilation()

        # =========================================================
        # Module 4: Runtime Execution
        # =========================================================
        self.profiler.start_execution()

        vm = TACVirtualMachine()
        vm.load(optimized_tac)
        vm_output, exit_code, cycles = vm.run()

        native_res = None
        if use_native_gcc:
            # Also try native gcc execution
            native_res = run_with_native_gcc(source_code)

        self.profiler.end_execution()

        # =========================================================
        # Module 5: Performance Profiling & Optimization Report
        # =========================================================
        perf_report = self.profiler.generate_report(all_diagnostics, opt_stats, cycles)

        # Format output texts
        raw_tac_text = "\n".join(str(inst) for inst in raw_tac)
        opt_tac_text = "\n".join(str(inst) for inst in optimized_tac)

        # Formulate status message
        error_count = sum(1 for d in all_diagnostics if d["severity"] == "Error")
        warning_count = sum(1 for d in all_diagnostics if d["severity"] == "Warning")
        recovered_count = sum(1 for d in all_diagnostics if d.get("recovered", False))

        if error_count == 0 and warning_count == 0:
            status_summary = "✓ Compilation successful"
            status_level = "success"
        elif recovered_count > 0:
            status_summary = f"✓ Compilation successful with Intelligent Error Recovery ({recovered_count} auto-recovered)"
            status_level = "recovered"
        else:
            status_summary = f"⚠ Compilation finished with {error_count} error(s) and {warning_count} warning(s)"
            status_level = "warning"

        return {
            "status": {
                "message": status_summary,
                "level": status_level,
                "error_count": error_count,
                "warning_count": warning_count,
                "recovered_count": recovered_count,
            },
            "tokens": [t.to_dict() for t in tokens if t.type.name != "EOF"],
            "diagnostics": all_diagnostics,
            "symbol_table": symbol_table.to_dict(),
            "intermediate_code": raw_tac_text,
            "optimized_code": opt_tac_text,
            "target_assembly": assembly_code,
            "program_output": vm_output,
            "exit_code": exit_code,
            "applied_optimizations": applied_opts,
            "performance": perf_report,
            "native_gcc": native_res,
        }
