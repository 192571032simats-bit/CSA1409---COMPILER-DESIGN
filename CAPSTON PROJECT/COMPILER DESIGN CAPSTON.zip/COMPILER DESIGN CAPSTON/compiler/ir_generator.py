"""
Module 3: Intermediate Code Generation (Three Address Code)
Converts AST into linear Three Address Code (TAC) instructions.
"""

from typing import List, Optional, Any
from dataclasses import dataclass
from compiler.ast_nodes import (
    ASTNode, ProgramNode, VarDeclNode, AssignNode, BinaryOpNode,
    UnaryOpNode, LiteralNode, VariableNode, BlockNode, IfNode,
    WhileNode, ForNode, ReturnNode, FunctionDeclNode, CoutNode,
    CinNode, ExpressionStatementNode
)


@dataclass
class TACInstruction:
    op: str
    arg1: Optional[str] = None
    arg2: Optional[str] = None
    result: Optional[str] = None
    comment: str = ""

    def __str__(self) -> str:
        if self.op == "label":
            return f"{self.result}:"
        elif self.op == "goto":
            return f"goto {self.result}"
        elif self.op == "if_false_goto":
            return f"ifFalse {self.arg1} goto {self.result}"
        elif self.op == "if_goto":
            return f"if {self.arg1} {self.arg2} goto {self.result}"
        elif self.op in ("+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">="):
            return f"{self.result} = {self.arg1} {self.op} {self.arg2}"
        elif self.op == "=":
            return f"{self.result} = {self.arg1}"
        elif self.op in ("neg", "not"):
            return f"{self.result} = {self.op} {self.arg1}"
        elif self.op == "print":
            return f"print {self.arg1}"
        elif self.op == "println":
            return f"println {self.arg1}"
        elif self.op == "read":
            return f"read {self.result}"
        elif self.op == "return":
            return f"return {self.arg1}" if self.arg1 is not None else "return"
        elif self.op == "func_begin":
            return f"\n--- Function {self.result} ---"
        elif self.op == "func_end":
            return f"--- End Function {self.result} ---\n"
        return f"{self.result} = {self.op} {self.arg1} {self.arg2}"

    def to_dict(self):
        return {
            "op": self.op,
            "arg1": self.arg1,
            "arg2": self.arg2,
            "result": self.result,
            "text": str(self),
            "comment": self.comment,
        }


class IRGenerator:
    """Generates Three Address Code from AST."""

    def __init__(self):
        self.instructions: List[TACInstruction] = []
        self.temp_counter = 0
        self.label_counter = 0

    def new_temp(self) -> str:
        self.temp_counter += 1
        return f"t{self.temp_counter}"

    def new_label(self) -> str:
        self.label_counter += 1
        return f"L{self.label_counter}"

    def emit(self, op: str, arg1: Optional[str] = None, arg2: Optional[str] = None, result: Optional[str] = None, comment: str = "") -> TACInstruction:
        instr = TACInstruction(op=op, arg1=arg1, arg2=arg2, result=result, comment=comment)
        self.instructions.append(instr)
        return instr

    def generate(self, ast: ProgramNode) -> List[TACInstruction]:
        self.instructions.clear()
        self.temp_counter = 0
        self.label_counter = 0

        for decl in ast.declarations:
            self.visit(decl)
        return self.instructions

    def visit(self, node: Optional[ASTNode]) -> Optional[str]:
        if node is None:
            return None

        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: ASTNode) -> Optional[str]:
        return None

    def visit_FunctionDeclNode(self, node: FunctionDeclNode) -> Optional[str]:
        self.emit("func_begin", result=node.name)
        if node.body:
            self.visit(node.body)
        self.emit("func_end", result=node.name)
        return None

    def visit_BlockNode(self, node: BlockNode) -> Optional[str]:
        for stmt in node.statements:
            self.visit(stmt)
        return None

    def visit_VarDeclNode(self, node: VarDeclNode) -> Optional[str]:
        if node.initializer:
            init_res = self.visit(node.initializer)
            self.emit("=", arg1=str(init_res), result=node.name)
        return node.name

    def visit_AssignNode(self, node: AssignNode) -> Optional[str]:
        val_res = self.visit(node.value)
        self.emit("=", arg1=str(val_res), result=node.name)
        return node.name

    def visit_ExpressionStatementNode(self, node: ExpressionStatementNode) -> Optional[str]:
        return self.visit(node.expr)

    def visit_LiteralNode(self, node: LiteralNode) -> str:
        if node.literal_type == "string":
            # Keep string quoted or formatted
            return f'"{node.value}"'
        elif node.literal_type == "char":
            return f"'{node.value}'"
        return str(node.value)

    def visit_VariableNode(self, node: VariableNode) -> str:
        return node.name

    def visit_BinaryOpNode(self, node: BinaryOpNode) -> str:
        left = self.visit(node.left)
        right = self.visit(node.right)
        temp = self.new_temp()
        self.emit(node.op, arg1=str(left), arg2=str(right), result=temp)
        return temp

    def visit_UnaryOpNode(self, node: UnaryOpNode) -> str:
        operand = self.visit(node.expr)
        if node.op in ("++", "--"):
            # Increment/decrement statement or expression
            temp = self.new_temp()
            delta = "1"
            bin_op = "+" if node.op == "++" else "-"
            self.emit(bin_op, arg1=str(operand), arg2=delta, result=temp)
            self.emit("=", arg1=temp, result=str(operand))
            return operand if node.is_postfix else temp
        elif node.op == "-":
            temp = self.new_temp()
            self.emit("neg", arg1=str(operand), result=temp)
            return temp
        elif node.op == "!":
            temp = self.new_temp()
            self.emit("not", arg1=str(operand), result=temp)
            return temp
        return str(operand)

    def visit_IfNode(self, node: IfNode) -> Optional[str]:
        cond_res = self.visit(node.condition)
        label_false = self.new_label()
        label_end = self.new_label()

        self.emit("if_false_goto", arg1=str(cond_res), result=label_false)
        if node.then_branch:
            self.visit(node.then_branch)

        if node.else_branch:
            self.emit("goto", result=label_end)
            self.emit("label", result=label_false)
            self.visit(node.else_branch)
            self.emit("label", result=label_end)
        else:
            self.emit("label", result=label_false)

        return None

    def visit_WhileNode(self, node: WhileNode) -> Optional[str]:
        label_start = self.new_label()
        label_end = self.new_label()

        self.emit("label", result=label_start)
        cond_res = self.visit(node.condition)
        self.emit("if_false_goto", arg1=str(cond_res), result=label_end)

        if node.body:
            self.visit(node.body)

        self.emit("goto", result=label_start)
        self.emit("label", result=label_end)
        return None

    def visit_ForNode(self, node: ForNode) -> Optional[str]:
        if node.init:
            self.visit(node.init)

        label_start = self.new_label()
        label_end = self.new_label()

        self.emit("label", result=label_start)

        if node.condition:
            cond_res = self.visit(node.condition)
            self.emit("if_false_goto", arg1=str(cond_res), result=label_end)

        if node.body:
            self.visit(node.body)

        if node.update:
            self.visit(node.update)

        self.emit("goto", result=label_start)
        self.emit("label", result=label_end)
        return None

    def visit_CoutNode(self, node: CoutNode) -> Optional[str]:
        for arg in node.args:
            arg_res = self.visit(arg)
            if str(arg_res) == '"\\n"':
                self.emit("println", arg1="")
            else:
                self.emit("print", arg1=str(arg_res))
        return None

    def visit_CinNode(self, node: CinNode) -> Optional[str]:
        for t in node.targets:
            self.emit("read", result=t)
        return None

    def visit_ReturnNode(self, node: ReturnNode) -> Optional[str]:
        ret_val = self.visit(node.value) if node.value else None
        self.emit("return", arg1=str(ret_val) if ret_val is not None else None)
        return None
