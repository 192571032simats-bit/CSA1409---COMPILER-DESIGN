"""
Module 1: Lexical Analyzer with Intelligent Error Recovery
"""

import re
from typing import List, Tuple, Dict, Any, Optional
from compiler.tokens import Token, TokenType, KEYWORDS


def levenshtein_distance(s1: str, s2: str) -> int:
    """Calculate the Damerau-Levenshtein distance between two strings (including transpositions)."""
    s1 = str(s1)
    s2 = str(s2)
    d = {}
    len1 = len(s1)
    len2 = len(s2)
    for i in range(-1, len1 + 1):
        d[(i, -1)] = i + 1
    for j in range(-1, len2 + 1):
        d[(-1, j)] = j + 1

    for i in range(len1):
        for j in range(len2):
            cost = 0 if s1[i] == s2[j] else 1
            d[(i, j)] = min(
                d[(i - 1, j)] + 1,       # deletion
                d[(i, j - 1)] + 1,       # insertion
                d[(i - 1, j - 1)] + cost # substitution
            )
            if i > 0 and j > 0 and s1[i] == s2[j - 1] and s1[i - 1] == s2[j]:
                d[(i, j)] = min(d[(i, j)], d[(i - 2, j - 2)] + 1) # transposition

    return d[(len1 - 1, len2 - 1)]


def find_closest_keyword(word: str, max_distance: int = 2) -> Optional[str]:
    """Find the closest valid C++ keyword if close enough."""
    best_match = None
    best_dist = max_distance + 1
    for kw in KEYWORDS:
        d = levenshtein_distance(word.lower(), kw)
        if d < best_dist:
            best_dist = d
            best_match = kw
    if best_dist <= max_distance:
        return best_match
    return None


class Lexer:
    """Lexer that breaks source code into tokens while intelligently detecting and recovering from errors."""

    def __init__(self, source_code: str):
        self.source = source_code
        self.length = len(source_code)
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.diagnostics: List[Dict[str, Any]] = []

    def log_diagnostic(
        self,
        severity: str,
        message: str,
        suggestion: str,
        line: int,
        column: int,
        recovered: bool = True,
        action: str = ""
    ):
        self.diagnostics.append({
            "phase": "Lexical",
            "severity": severity,
            "message": message,
            "suggestion": suggestion,
            "line": line,
            "column": column,
            "recovered": recovered,
            "action": action
        })

    def peek(self, offset: int = 0) -> str:
        idx = self.pos + offset
        if idx < self.length:
            return self.source[idx]
        return ""

    def advance(self) -> str:
        if self.pos < self.length:
            ch = self.source[self.pos]
            self.pos += 1
            if ch == "\n":
                self.line += 1
                self.column = 1
            else:
                self.column += 1
            return ch
        return ""

    def skip_whitespace_and_comments(self):
        while self.pos < self.length:
            ch = self.peek()
            if ch in " \t\r\n":
                self.advance()
            # Single-line comment
            elif ch == "/" and self.peek(1) == "/":
                while self.pos < self.length and self.peek() != "\n":
                    self.advance()
            # Multi-line comment
            elif ch == "/" and self.peek(1) == "*":
                start_line = self.line
                start_col = self.column
                self.advance()  # /
                self.advance()  # *
                closed = False
                while self.pos < self.length:
                    if self.peek() == "*" and self.peek(1) == "/":
                        self.advance()
                        self.advance()
                        closed = True
                        break
                    self.advance()
                if not closed:
                    self.log_diagnostic(
                        severity="Warning",
                        message="Unclosed multi-line comment /*",
                        suggestion="Add closing '*/' at end of comment.",
                        line=start_line,
                        column=start_col,
                        recovered=True,
                        action="Implicitly closed comment at EOF"
                    )
            else:
                break

    def tokenize(self) -> Tuple[List[Token], List[Dict[str, Any]]]:
        """Tokenize entire source and return (tokens, diagnostics)."""
        while self.pos < self.length:
            self.skip_whitespace_and_comments()
            if self.pos >= self.length:
                break

            ch = self.peek()
            start_line = self.line
            start_col = self.column

            # Preprocessor directives: e.g. #include <iostream>
            if ch == "#":
                self.advance()
                directive_line = ""
                while self.pos < self.length and self.peek() != "\n":
                    directive_line += self.advance()
                self.tokens.append(
                    Token(
                        type=TokenType.PREPROCESSOR,
                        value="#" + directive_line.strip(),
                        line=start_line,
                        column=start_col,
                        raw="#" + directive_line.strip(),
                    )
                )
                continue

            # Strings
            if ch == '"':
                self.advance()  # skip opening quote
                s_val = ""
                closed = False
                while self.pos < self.length:
                    curr = self.peek()
                    if curr == '"':
                        self.advance()
                        closed = True
                        break
                    elif curr == "\n":
                        # Unterminated string on line
                        break
                    elif curr == "\\":
                        self.advance()
                        nxt = self.advance()
                        if nxt == "n":
                            s_val += "\n"
                        elif nxt == "t":
                            s_val += "\t"
                        elif nxt == "\\":
                            s_val += "\\"
                        elif nxt == '"':
                            s_val += '"'
                        else:
                            s_val += nxt
                    else:
                        s_val += self.advance()

                if not closed:
                    self.log_diagnostic(
                        severity="Error",
                        message=f'Unterminated string literal starting at column {start_col}',
                        suggestion='Add closing double quote \'"\'.',
                        line=start_line,
                        column=start_col,
                        recovered=True,
                        action="Automatically appended closing quote"
                    )

                self.tokens.append(
                    Token(
                        type=TokenType.STRING_LITERAL,
                        value=s_val,
                        line=start_line,
                        column=start_col,
                        raw=f'"{s_val}"',
                    )
                )
                continue

            # Characters
            if ch == "'":
                self.advance()
                c_val = ""
                if self.peek() == "\\":
                    self.advance()
                    nxt = self.advance()
                    c_val = "\n" if nxt == "n" else ("\t" if nxt == "t" else nxt)
                else:
                    c_val = self.advance()
                if self.peek() == "'":
                    self.advance()
                else:
                    self.log_diagnostic(
                        severity="Error",
                        message="Unterminated char literal",
                        suggestion="Add closing single quote '\''.",
                        line=start_line,
                        column=start_col,
                        recovered=True,
                        action="Automatically closed char literal"
                    )
                self.tokens.append(
                    Token(
                        type=TokenType.CHAR_LITERAL,
                        value=c_val,
                        line=start_line,
                        column=start_col,
                        raw=f"'{c_val}'",
                    )
                )
                continue

            # Numbers (integers and floats)
            if ch.isdigit():
                num_str = ""
                is_float = False
                while self.pos < self.length and (self.peek().isdigit() or self.peek() == "."):
                    if self.peek() == ".":
                        if is_float:
                            break
                        is_float = True
                    num_str += self.advance()

                # Check for malformed identifier starting with digit like "123var"
                if self.pos < self.length and (self.peek().isalpha() or self.peek() == "_"):
                    ident_part = ""
                    while self.pos < self.length and (self.peek().isalnum() or self.peek() == "_"):
                        ident_part += self.advance()
                    self.log_diagnostic(
                        severity="Error",
                        message=f"Invalid identifier '{num_str}{ident_part}': Identifiers cannot start with numbers.",
                        suggestion=f"Separate into number '{num_str}' and identifier '{ident_part}', or rename to '_{num_str}{ident_part}'.",
                        line=start_line,
                        column=start_col,
                        recovered=True,
                        action="Separated into numeric literal and identifier"
                    )
                    # Push number and identifier
                    if is_float:
                        self.tokens.append(Token(TokenType.FLOAT_LITERAL, float(num_str), start_line, start_col, num_str))
                    else:
                        self.tokens.append(Token(TokenType.INT_LITERAL, int(num_str), start_line, start_col, num_str))
                    self.tokens.append(Token(TokenType.IDENTIFIER, ident_part, start_line, start_col + len(num_str), ident_part))
                    continue

                if is_float:
                    self.tokens.append(
                        Token(TokenType.FLOAT_LITERAL, float(num_str), start_line, start_col, num_str)
                    )
                else:
                    self.tokens.append(
                        Token(TokenType.INT_LITERAL, int(num_str), start_line, start_col, num_str)
                    )
                continue

            # Identifiers and Keywords
            if ch.isalpha() or ch == "_":
                word = ""
                while self.pos < self.length and (self.peek().isalnum() or self.peek() == "_"):
                    word += self.advance()

                if word in KEYWORDS:
                    self.tokens.append(
                        Token(type=KEYWORDS[word], value=word, line=start_line, column=start_col, raw=word)
                    )
                else:
                    # Check if it's a slightly misspelled keyword
                    closest_kw = find_closest_keyword(word)
                    # If it's very close and not a standard common variable name, log suggestion
                    if closest_kw and closest_kw != word and len(word) >= 3 and levenshtein_distance(word, closest_kw) == 1:
                        # e.g. "itn" -> "int", "retunr" -> "return", "doubel" -> "double"
                        # We will treat it as the keyword with recovery, but also keep identifier option if context dictates
                        self.log_diagnostic(
                            severity="Warning",
                            message=f"Possible typo in keyword '{word}'.",
                            suggestion=f"Did you mean '{closest_kw}'?",
                            line=start_line,
                            column=start_col,
                            recovered=True,
                            action=f"Intelligently interpreted as keyword '{closest_kw}'"
                        )
                        self.tokens.append(
                            Token(type=KEYWORDS[closest_kw], value=closest_kw, line=start_line, column=start_col, raw=word)
                        )
                    else:
                        self.tokens.append(
                            Token(type=TokenType.IDENTIFIER, value=word, line=start_line, column=start_col, raw=word)
                        )
                continue

            # Multi-character operators
            two_chars = ch + self.peek(1)
            if two_chars == "==":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_EQ, "==", start_line, start_col, "=="))
                continue
            elif two_chars == "!=":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_NE, "!=", start_line, start_col, "!="))
                continue
            elif two_chars == "<=":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_LE, "<=", start_line, start_col, "<="))
                continue
            elif two_chars == ">=":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_GE, ">=", start_line, start_col, ">="))
                continue
            elif two_chars == "<<":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_LSHIFT, "<<", start_line, start_col, "<<"))
                continue
            elif two_chars == ">>":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_RSHIFT, ">>", start_line, start_col, ">>"))
                continue
            elif two_chars == "++":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_INC, "++", start_line, start_col, "++"))
                continue
            elif two_chars == "--":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_DEC, "--", start_line, start_col, "--"))
                continue
            elif two_chars == "&&":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_AND, "&&", start_line, start_col, "&&"))
                continue
            elif two_chars == "||":
                self.advance(); self.advance()
                self.tokens.append(Token(TokenType.OP_OR, "||", start_line, start_col, "||"))
                continue

            # Single character operators & delimiters
            single_map = {
                "=": TokenType.OP_ASSIGN,
                "+": TokenType.OP_PLUS,
                "-": TokenType.OP_MINUS,
                "*": TokenType.OP_MUL,
                "/": TokenType.OP_DIV,
                "%": TokenType.OP_MOD,
                "<": TokenType.OP_LT,
                ">": TokenType.OP_GT,
                "!": TokenType.OP_NOT,
                ";": TokenType.SEMICOLON,
                ",": TokenType.COMMA,
                "(": TokenType.LPAREN,
                ")": TokenType.RPAREN,
                "{": TokenType.LBRACE,
                "}": TokenType.RBRACE,
                "[": TokenType.LBRACKET,
                "]": TokenType.RBRACKET,
            }

            if ch in single_map:
                self.advance()
                self.tokens.append(
                    Token(type=single_map[ch], value=ch, line=start_line, column=start_col, raw=ch)
                )
                continue

            # Invalid or stray characters (e.g. '@' as shown in Slide 9)
            invalid_char = self.advance()
            self.log_diagnostic(
                severity="Error",
                message=f"Lexical Error: Unrecognized or stray character '{invalid_char}' found.",
                suggestion=f"Remove stray '{invalid_char}' symbol or replace with valid token.",
                line=start_line,
                column=start_col,
                recovered=True,
                action=f"Auto-recovered: Skipped illegal character '{invalid_char}' and continued compilation."
            )

        # End of file token
        self.tokens.append(Token(TokenType.EOF, "EOF", self.line, self.column, "EOF"))
        return self.tokens, self.diagnostics
