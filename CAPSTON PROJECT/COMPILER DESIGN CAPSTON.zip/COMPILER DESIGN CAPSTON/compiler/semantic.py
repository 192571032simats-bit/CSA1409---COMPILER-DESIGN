"""
Module 2: Semantic Analysis and Intelligent Error Recovery
Performs type checking, scope validation, symbol resolution, and intelligent recovery.
"""

from typing import List, Dict, Any, Optional, Tuple
from compiler.symbol_table import SymbolTable, Symbol
from compiler.lexer import levenshtein_distance
from compiler.ast_nodes import (
    ASTNode, ProgramNode, PreprocessorNode, UsingNamespaceNode,
    VarDeclNode, AssignNode, BinaryOpNode, UnaryOpNode,
    LiteralNode, VariableNode, BlockNode, IfNode, WhileNode,
    ForNode, ReturnNode, FunctionDeclNode, CoutNode, CinNode,
    ExpressionStatementNode
)


class SemanticAnalyzer:
    """Semantic Analyzer with AI Rule Engine and automatic error recovery."""

    def __init__(self):
        self.diagnostics: List[Dict[str, Any]] = []
        self.global_scope = SymbolTable(scope_name="global")
        self.current_scope = self.global_scope
        self.current_function: Optional[FunctionDeclNode] = None

    def log_diagnostic(
        self,
        severity: str,
        message: str,
        suggestion: str,
        line: int,
        column: int,
        recovered: bool = True,
        action: str = ""
    ):
        self.diagnostics.append({
            "phase": "Semantic",
            "severity": severity,
            "message": message,
            "suggestion": suggestion,
            "line": line,
            "column": column,
            "recovered": recovered,
            "action": action
        })

    def find_closest_symbol(self, name: str) -> Optional[str]:
        """AI Rule Engine: Find closest declared variable name using fuzzy matching."""
        visible = self.current_scope.get_all_visible_symbols()
        best_match = None
        best_dist = 3  # threshold
        name_str = str(name)
        for cand in visible:
            cand_str = str(cand)
            d = levenshtein_distance(name_str, cand_str)
            if d < best_dist:
                best_dist = d
                best_match = cand_str
        return best_match

    def analyze(self, ast: ProgramNode) -> Tuple[ProgramNode, SymbolTable, List[Dict[str, Any]]]:
        """Analyze entire AST program."""
        for decl in ast.declarations:
            self.visit_node(decl)
        return ast, self.global_scope, self.diagnostics

    def visit_node(self, node: Optional[ASTNode]):
        if node is None:
            return

        method_name = f"visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: ASTNode):
        for k, v in node.__dict__.items():
            if isinstance(v, ASTNode):
                self.visit_node(v)
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, ASTNode):
                        self.visit_node(item)

    def visit_PreprocessorNode(self, node: PreprocessorNode):
        pass

    def visit_UsingNamespaceNode(self, node: UsingNamespaceNode):
        pass

    def visit_FunctionDeclNode(self, node: FunctionDeclNode):
        # Register function symbol in current scope
        self.global_scope.insert(
            name=node.name,
            var_type=f"function()->{node.return_type}",
            line=node.line,
            column=node.column,
            is_initialized=True
        )

        old_func = self.current_function
        self.current_function = node

        # Create new scope for function body
        func_scope = SymbolTable(parent=self.current_scope, scope_name=f"func_{node.name}")
        self.current_scope = func_scope

        # Register parameters
        for p in node.params:
            func_scope.insert(p.name, p.param_type, p.line, p.column, is_initialized=True)

        if node.body:
            for stmt in node.body.statements:
                self.visit_node(stmt)

        self.current_scope = self.current_scope.parent or self.global_scope
        self.current_function = old_func

    def visit_BlockNode(self, node: BlockNode):
        block_scope = SymbolTable(parent=self.current_scope, scope_name="block")
        self.current_scope = block_scope
        for stmt in node.statements:
            self.visit_node(stmt)
        self.current_scope = self.current_scope.parent or self.global_scope

    def visit_VarDeclNode(self, node: VarDeclNode):
        # Check redeclaration in current scope
        if node.name in self.current_scope.symbols:
            existing = self.current_scope.symbols[node.name]
            self.log_diagnostic(
                severity="Warning",
                message=f"Semantic Warning: Redeclaration of variable '{node.name}' in same scope (previously declared at line {existing.line}).",
                suggestion=f"Use a different name or remove duplicate declaration of '{node.name}'.",
                line=node.line,
                column=node.column,
                recovered=True,
                action="Allowed redeclaration by updating symbol attributes"
            )

        has_init = node.initializer is not None
        self.current_scope.insert(
            name=node.name,
            var_type=node.var_type,
            line=node.line,
            column=node.column,
            is_initialized=has_init
        )

        if has_init:
            self.visit_node(node.initializer)
            init_type = self.check_expression_type(node.initializer)
            if init_type and init_type != "unknown" and init_type != node.var_type:
                # Type conversion or mismatch
                if node.var_type == "int" and init_type == "float":
                    self.log_diagnostic(
                        severity="Warning",
                        message=f"Implicit conversion from float to int in initialization of '{node.name}'.",
                        suggestion="Cast explicitly or declare variable as float.",
                        line=node.line,
                        column=node.column,
                        recovered=True,
                        action="Truncated float value to integer"
                    )
                elif init_type == "string" and node.var_type in ("int", "float", "bool"):
                    self.log_diagnostic(
                        severity="Error",
                        message=f"Semantic Error: Cannot initialize '{node.var_type}' variable '{node.name}' with string literal.",
                        suggestion=f"Assign a numeric value compatible with '{node.var_type}'.",
                        line=node.line,
                        column=node.column,
                        recovered=True,
                        action="Auto-converted string to 0 to prevent type error."
                    )

    def visit_AssignNode(self, node: AssignNode):
        sym = self.current_scope.lookup(node.name, mark_used=True)
        if not sym:
            # Undeclared variable!
            closest = self.find_closest_symbol(node.name)
            sugg = f"Did you mean '{closest}'?" if closest else f"Declare 'int {node.name};' before assigning."
            self.log_diagnostic(
                severity="Error",
                message=f"Semantic Error: Assignment to undeclared variable '{node.name}'.",
                suggestion=sugg,
                line=node.line,
                column=node.column,
                recovered=True,
                action=f"Auto-recovered: Automatically declared '{node.name}' as int in current scope."
            )
            self.current_scope.insert(node.name, "int", node.line, node.column, is_initialized=True)
        else:
            sym.is_initialized = True

        if node.value:
            self.visit_node(node.value)

    def visit_VariableNode(self, node: VariableNode):
        sym = self.current_scope.lookup(node.name, mark_used=True)
        if not sym:
            # Intelligent recovery for undeclared variable read
            closest = self.find_closest_symbol(node.name)
            sugg = f"Did you mean '{closest}'?" if closest else f"Declare variable '{node.name}' before use."
            self.log_diagnostic(
                severity="Error",
                message=f"Semantic Error: Use of undeclared variable '{node.name}'.",
                suggestion=sugg,
                line=node.line,
                column=node.column,
                recovered=True,
                action=f"Auto-recovered: Inferred and declared variable '{node.name}' as int initialized to 0."
            )
            # Auto-declare so subsequent phases don't break
            self.current_scope.insert(node.name, "int", node.line, node.column, is_initialized=True)
        elif not sym.is_initialized:
            self.log_diagnostic(
                severity="Warning",
                message=f"Semantic Warning: Variable '{node.name}' may be used uninitialized.",
                suggestion=f"Initialize '{node.name}' before reading its value.",
                line=node.line,
                column=node.column,
                recovered=True,
                action="Assumed default zero value"
            )

    def visit_BinaryOpNode(self, node: BinaryOpNode):
        if node.left:
            self.visit_node(node.left)
        if node.right:
            self.visit_node(node.right)

    def visit_UnaryOpNode(self, node: UnaryOpNode):
        if node.expr:
            self.visit_node(node.expr)

    def visit_IfNode(self, node: IfNode):
        if node.condition:
            self.visit_node(node.condition)
        if node.then_branch:
            self.visit_node(node.then_branch)
        if node.else_branch:
            self.visit_node(node.else_branch)

    def visit_WhileNode(self, node: WhileNode):
        if node.condition:
            self.visit_node(node.condition)
        if node.body:
            self.visit_node(node.body)

    def visit_ForNode(self, node: ForNode):
        for_scope = SymbolTable(parent=self.current_scope, scope_name="for_loop")
        self.current_scope = for_scope
        if node.init:
            self.visit_node(node.init)
        if node.condition:
            self.visit_node(node.condition)
        if node.update:
            self.visit_node(node.update)
        if node.body:
            self.visit_node(node.body)
        self.current_scope = self.current_scope.parent or self.global_scope

    def visit_CoutNode(self, node: CoutNode):
        for arg in node.args:
            self.visit_node(arg)

    def visit_CinNode(self, node: CinNode):
        for t in node.targets:
            sym = self.current_scope.lookup(t, mark_used=True)
            if not sym:
                self.log_diagnostic(
                    severity="Error",
                    message=f"Semantic Error: cin target '{t}' is undeclared.",
                    suggestion=f"Declare variable 'int {t};' before cin.",
                    line=node.line,
                    column=node.column,
                    recovered=True,
                    action=f"Auto-recovered: Automatically declared '{t}' as int"
                )
                self.current_scope.insert(t, "int", node.line, node.column, is_initialized=True)
            else:
                sym.is_initialized = True

    def visit_ReturnNode(self, node: ReturnNode):
        if node.value:
            self.visit_node(node.value)

    def visit_ExpressionStatementNode(self, node: ExpressionStatementNode):
        if node.expr:
            self.visit_node(node.expr)

    def check_expression_type(self, node: Optional[ASTNode]) -> str:
        """Infer type of an expression."""
        if not node:
            return "void"
        if isinstance(node, LiteralNode):
            return node.literal_type
        if isinstance(node, VariableNode):
            sym = self.current_scope.lookup(node.name)
            return sym.var_type if sym else "int"
        if isinstance(node, BinaryOpNode):
            lt = self.check_expression_type(node.left)
            rt = self.check_expression_type(node.right)
            if "float" in (lt, rt):
                return "float"
            return "int"
        return "int"
