"""
Command Line Interface (CLI) for Intelligent C++ Compiler
Allows compiling and running C++ files directly from terminal with diagnostic reporting.
"""

import argparse
import sys
import os

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

from compiler import IntelligentCompiler


def main():
    parser = argparse.ArgumentParser(
        description="Intelligent Programming Language Compiler with Error Recovery and Optimization"
    )
    parser.add_argument("file", nargs="?", help="Path to C++ source file")
    parser.add_argument("-e", "--emit-tac", action="store_true", help="Print Three Address Code (TAC)")
    parser.add_argument("-o", "--emit-opt", action="store_true", help="Print Optimized Intermediate Code")
    parser.add_argument("-s", "--emit-asm", action="store_true", help="Print Target Assembly (x86-64)")
    parser.add_argument("-t", "--tokens", action="store_true", help="Print Token list")
    parser.add_argument("-d", "--diagnostics", action="store_true", help="Print detailed Error Recovery Diagnostics")
    parser.add_argument("-p", "--performance", action="store_true", help="Print Performance and Optimization Report")
    parser.add_argument("--native", action="store_true", help="Compile and run natively using GCC/G++")

    args = parser.parse_args()

    # Default demo code if no file specified
    if not args.file:
        source_code = """#include <iostream>
using namespace std;

int main()
{
    int a = 10;
    int b = 20;

    int sum = a + b;

    cout << "Sum = " << sum << endl;

    return 0;
}"""
        print("[Intelligent Compiler] No file specified. Running default Sum Demo...\n")
    else:
        if not os.path.exists(args.file):
            print(f"Error: File '{args.file}' not found.")
            sys.exit(1)
        with open(args.file, "r", encoding="utf-8") as f:
            source_code = f.read()

    compiler = IntelligentCompiler()
    result = compiler.compile_and_run(source_code, use_native_gcc=args.native)

    status = result["status"]
    print(f"Status: {status['message']}")

    if args.tokens:
        print("\n=== TOKENS ===")
        for idx, t in enumerate(result["tokens"]):
            print(f"[{idx+1:03d}] {t['type']:<18} '{t['value']}' (Line {t['line']}:{t['column']})")

    if args.diagnostics or status["recovered_count"] > 0 or status["error_count"] > 0:
        print("\n=== DIAGNOSTICS & RECOVERY REPORT ===")
        for d in result["diagnostics"]:
            rec = "✓ AUTO-RECOVERED" if d.get("recovered") else "UNRESOLVED"
            print(f"[{d['severity'].upper()}] ({d['phase']} Phase - Line {d['line']}:{d['column']}) {rec}")
            print(f"  Issue:      {d['message']}")
            print(f"  Suggestion: {d['suggestion']}")
            if d.get("action"):
                print(f"  Action:     {d['action']}")

    if args.emit_tac:
        print("\n=== THREE ADDRESS CODE (BEFORE OPTIMIZATION) ===")
        print(result["intermediate_code"])

    if args.emit_opt:
        print("\n=== OPTIMIZED INTERMEDIATE CODE ===")
        print(result["optimized_code"])
        if result["applied_optimizations"]:
            print("\nApplied Optimizations:")
            for opt in result["applied_optimizations"]:
                print(f"  • [{opt['pass']}] {opt['details']}")

    if args.emit_asm:
        print("\n=== TARGET ASSEMBLY (x86-64) ===")
        print(result["target_assembly"])

    print("\n=== PROGRAM OUTPUT ===")
    print(result["program_output"])

    if args.performance:
        p = result["performance"]
        print("\n=== PERFORMANCE REPORT ===")
        print(f"  Compilation Time:      {p['compilation_time_ms']} ms")
        print(f"  Execution Time:        {p['execution_time_ms']} ms")
        print(f"  Memory Footprint:      {p['memory_usage_kb']} KB")
        print(f"  CPU Utilization:       {p['cpu_utilization_pct']} %")
        print(f"  Optimization Ratio:    {p['optimization_percentage']} % ({p['instructions_saved']} instructions saved)")
        print(f"  Error Recovery Rate:   {p['error_recovery_rate']} % ({p['errors_recovered']}/{p['total_errors_detected']} recovered)")


if __name__ == "__main__":
    main()
