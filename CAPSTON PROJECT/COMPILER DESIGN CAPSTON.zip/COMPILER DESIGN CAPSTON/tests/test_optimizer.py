"""
Module 5: Unit Tests for Module 3 (Optimizer: Constant Folding, DCE, CSE, Strength Reduction)
"""

import pytest
from compiler.ir_generator import TACInstruction
from compiler.optimizer import Optimizer


def test_constant_folding():
    optimizer = Optimizer()
    instrs = [
        TACInstruction(op="+", arg1="10", arg2="20", result="t1"),
        TACInstruction(op="=", arg1="t1", result="sum"),
        TACInstruction(op="print", arg1="sum"),
    ]
    opt_instrs, applied, stats = optimizer.optimize(instrs)
    assert any(op["pass"] == "Constant Folding" for op in applied)
    # Result should have sum = 30
    assert any(i.result == "sum" and i.arg1 == "30" for i in opt_instrs)


def test_strength_reduction():
    optimizer = Optimizer()
    instrs = [
        TACInstruction(op="*", arg1="x", arg2="2", result="t1"),
        TACInstruction(op="print", arg1="t1"),
    ]
    opt_instrs, applied, stats = optimizer.optimize(instrs)
    assert any(op["pass"] == "Strength Reduction" for op in applied)
    # Replaced with x + x
    assert any(i.op == "+" and i.arg1 == "x" and i.arg2 == "x" for i in opt_instrs)


def test_common_subexpression_elimination():
    optimizer = Optimizer()
    instrs = [
        TACInstruction(op="+", arg1="a", arg2="b", result="t1"),
        TACInstruction(op="=", arg1="t1", result="c"),
        TACInstruction(op="+", arg1="a", arg2="b", result="t2"),
        TACInstruction(op="=", arg1="t2", result="d"),
        TACInstruction(op="print", arg1="c"),
        TACInstruction(op="print", arg1="d"),
    ]
    opt_instrs, applied, stats = optimizer.optimize(instrs)
    assert any(op["pass"] == "Common Subexpression Elimination" for op in applied)
