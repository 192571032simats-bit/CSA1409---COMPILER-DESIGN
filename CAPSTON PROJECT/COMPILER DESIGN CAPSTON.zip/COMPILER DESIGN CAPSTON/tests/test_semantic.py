"""
Module 5: Unit Tests for Module 2 (Semantic Analysis and Intelligent Recovery)
"""

import pytest
from compiler.lexer import Lexer
from compiler.parser import Parser
from compiler.semantic import SemanticAnalyzer


def test_semantic_valid_program():
    code = """
    int main() {
        int a = 10;
        int b = 20;
        int sum = a + b;
        return 0;
    }
    """
    tokens, _ = Lexer(code).tokenize()
    ast, _ = Parser(tokens).parse()
    analyzer = SemanticAnalyzer()
    _, sym_tab, diags = analyzer.analyze(ast)
    assert len(diags) == 0


def test_semantic_undeclared_variable_recovery():
    code = """
    int main() {
        int a = 10;
        int sum = a + undeclared_var;
        return 0;
    }
    """
    tokens, _ = Lexer(code).tokenize()
    ast, _ = Parser(tokens).parse()
    analyzer = SemanticAnalyzer()
    _, sym_tab, diags = analyzer.analyze(ast)
    assert len(diags) >= 1
    assert any("undeclared variable" in d["message"].lower() for d in diags)
    # The undeclared variable should be auto-recovered into scope
    assert any(d.get("recovered") for d in diags)


def test_semantic_fuzzy_match_suggestion():
    code = """
    int main() {
        int myCounter = 5;
        int next = myCounte + 1;
        return 0;
    }
    """
    tokens, _ = Lexer(code).tokenize()
    ast, _ = Parser(tokens).parse()
    analyzer = SemanticAnalyzer()
    _, _, diags = analyzer.analyze(ast)
    # Should suggest 'myCounter'
    assert any("myCounter" in d.get("suggestion", "") for d in diags)
