"""
Module 5: Integration Tests for Full 5-Module Compilation Pipeline
"""

import pytest
from compiler import IntelligentCompiler


def test_full_pipeline_slide15_sum_example():
    code = """#include <iostream>
using namespace std;

int main()
{
    int a = 10;
    int b = 20;

    int sum = a + b;

    cout << "Sum = " << sum << endl;

    return 0;
}
"""
    compiler = IntelligentCompiler()
    result = compiler.compile_and_run(code)

    assert result["status"]["level"] == "success"
    assert "Sum = 30" in result["program_output"]
    assert result["performance"]["optimization_percentage"] > 0
    assert result["performance"]["error_recovery_rate"] == 100.0


def test_full_pipeline_loop_example():
    code = """#include <iostream>
using namespace std;

int main() {
    int sum = 0;
    for (int i = 1; i <= 5; i++) {
        sum = sum + i;
    }
    cout << "Loop Sum = " << sum << endl;
    return 0;
}
"""
    compiler = IntelligentCompiler()
    result = compiler.compile_and_run(code)

    assert result["status"]["level"] == "success"
    assert "Loop Sum = 15" in result["program_output"]


def test_full_pipeline_intelligent_recovery():
    code = """#include <iostream>
using namespace std;

int main() {
    int a = 10;
    @
    itn b = 20
    int sum = a + b;
    cout << "Recovered Sum = " << sum << endl;
    return 0;
}
"""
    compiler = IntelligentCompiler()
    result = compiler.compile_and_run(code)

    assert result["status"]["level"] == "recovered"
    assert "Recovered Sum = 30" in result["program_output"]
    assert result["performance"]["errors_recovered"] >= 3
