"""
Module 5: Unit Tests for Module 1 (Lexical Analyzer)
"""

import pytest
from compiler.tokens import TokenType
from compiler.lexer import Lexer, levenshtein_distance, find_closest_keyword


def test_lex_basic_tokens():
    code = "int a = 10; float b = 2.5;"
    tokens, diags = Lexer(code).tokenize()
    types = [t.type for t in tokens if t.type != TokenType.EOF]
    assert types == [
        TokenType.KEYWORD_INT, TokenType.IDENTIFIER, TokenType.OP_ASSIGN, TokenType.INT_LITERAL, TokenType.SEMICOLON,
        TokenType.KEYWORD_FLOAT, TokenType.IDENTIFIER, TokenType.OP_ASSIGN, TokenType.FLOAT_LITERAL, TokenType.SEMICOLON
    ]
    assert len(diags) == 0


def test_lex_illegal_character_recovery():
    # Stray '@' as in Slide 9
    code = "int a = 10; @ return 0;"
    tokens, diags = Lexer(code).tokenize()
    assert len(diags) == 1
    assert diags[0]["severity"] == "Error"
    assert "@" in diags[0]["message"]
    assert diags[0]["recovered"] is True
    # Tokens should skip '@' and continue
    types = [t.type for t in tokens if t.type != TokenType.EOF]
    assert TokenType.KEYWORD_RETURN in types


def test_lex_keyword_typo_recovery():
    code = "itn a = 10; retunr a;"
    tokens, diags = Lexer(code).tokenize()
    assert len(diags) >= 2
    types = [t.type for t in tokens if t.type != TokenType.EOF]
    assert types[0] == TokenType.KEYWORD_INT
    assert types[5] == TokenType.KEYWORD_RETURN


def test_levenshtein_distance():
    assert levenshtein_distance("int", "itn") == 1
    assert levenshtein_distance("return", "retunr") == 1
    assert levenshtein_distance("cout", "cout") == 0
