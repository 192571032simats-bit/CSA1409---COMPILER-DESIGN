"""
Module 5: Unit Tests for Module 1 (Parser and Syntax Error Recovery)
"""

import pytest
from compiler.lexer import Lexer
from compiler.parser import Parser
from compiler.ast_nodes import ProgramNode, FunctionDeclNode, VarDeclNode


def test_parse_valid_sum():
    code = """
    int main() {
        int a = 10;
        int b = 20;
        return a + b;
    }
    """
    tokens, _ = Lexer(code).tokenize()
    ast, diags = Parser(tokens).parse()
    assert isinstance(ast, ProgramNode)
    assert len(diags) == 0
    assert len(ast.declarations) == 1
    assert isinstance(ast.declarations[0], FunctionDeclNode)


def test_parse_missing_semicolon_recovery():
    code = """
    int main() {
        int a = 10
        int b = 20;
        return a + b;
    }
    """
    tokens, _ = Lexer(code).tokenize()
    ast, diags = Parser(tokens).parse()
    # Should catch missing semicolon and auto-insert it
    assert len(diags) >= 1
    assert any("Missing semicolon" in d["message"] for d in diags)
    assert ast.declarations[0].body is not None
    assert len(ast.declarations[0].body.statements) == 3


def test_parse_missing_closing_brace_recovery():
    code = """
    int main() {
        int a = 10;
        return a;
    """
    tokens, _ = Lexer(code).tokenize()
    ast, diags = Parser(tokens).parse()
    assert any("Missing closing brace" in d["message"] for d in diags)
    assert len(ast.declarations[0].body.statements) == 2
