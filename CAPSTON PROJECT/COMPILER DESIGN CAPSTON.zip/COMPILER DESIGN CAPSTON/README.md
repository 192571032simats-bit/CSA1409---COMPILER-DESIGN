# Intelligent Programming Language Compiler with Error Recovery and Optimization

> **Academic Capstone Project — CSA1420: Compiler Design**  
> **Guided by:** Dr. N. DEEPA, Professor  
> **Presented by:** E. RAGUL (192571032), S. SUNDARESAN (192411245), H. MOHAMED FAAIZ (192524099)

---

## 1. Project Overview

Conventional compilers (e.g. GCC, Clang) often halt upon encountering severe syntax or lexical errors, provide obscure or cascading diagnostic messages, require tedious manual debugging, and produce code with basic optimizations.

This project implements an **Intelligent Programming Language Compiler** designed to:
1. **Intelligently detect and recover** from lexical, syntax, and semantic errors using rule-based and fuzzy-matching AI heuristics to continue compilation without premature halting.
2. **Generate linear intermediate representation (Three Address Code / TAC)**.
3. **Perform multi-pass code optimizations**, including constant folding, dead-code elimination, copy propagation, common-subexpression elimination, and strength reduction.
4. **Generate target assembly code (x86-64 Intel syntax)** with register allocation.
5. **Execute compiled programs** via a high-performance TAC Virtual Machine or native GCC compilation.
6. **Provide real-time compiler performance profiling** reporting compilation time, execution time, memory footprint, CPU utilization, optimization ratio, and error recovery rate.
7. **Deliver an interactive, dark-themed GUI** faithfully reproducing the presentation's Slide 15 software demonstration.

---

## 2. System Architecture

The compiler architecture follows the 4-phase pipeline with 5 supporting components:

```
+---------------------------------------------------------------------------------------+
|                                COMPILER ARCHITECTURE                                  |
+---------------------------------------------------------------------------------------+
| [1] INPUT           -->  [2] ANALYSIS        -->  [3] CODE GEN & OPT  -->  [4] OUTPUT |
| Source Program           - Lexical Analysis       - TAC Generation         - Exec VM  |
| (C++ Subset)             - Syntax Analysis        - Optimization           - Reports  |
|                          - Semantic Analysis      - Target x86 Assembly    - Profiler |
+---------------------------------------------------------------------------------------+
|                                SUPPORTING COMPONENTS                                  |
|   * Symbol Table Manager  * AI Error Recovery Engine  * Grammar Rules  * Profiler     |
+---------------------------------------------------------------------------------------+
```

---

## 3. Five-Module Implementation Breakdown

### Module 1: Lexical and Syntax Error Detection & Recovery
- **Lexer (`compiler/lexer.py`, `compiler/tokens.py`)**:
  - Tokenizes C++ programs recognizing keywords, identifiers, numeric literals (int, float), string literals, operators (`+`, `-`, `*`, `/`, `==`, `<=`, `<<`, `++`, etc.), and delimiters.
  - **Intelligent Error Recovery**:
    - **Stray / Illegal Characters**: Catches characters such as `@` (as depicted in Slide 9) and `$`, logs diagnostics with suggestions, automatically skips them, and continues tokenization.
    - **Keyword Typos**: Uses **Damerau-Levenshtein distance** to detect transposed or misspelled keywords (e.g. `itn` $\rightarrow$ `int`, `retunr` $\rightarrow$ `return`), suggests the correct keyword, and recovers the token.
    - **Unterminated Strings / Comments**: Automatically auto-terminates runaway literals and comments.
- **Parser (`compiler/parser.py`, `compiler/ast_nodes.py`)**:
  - Builds an Abstract Syntax Tree (AST) using recursive descent with precedence climbing.
  - **Intelligent Error Recovery**:
    - **Missing Semicolons**: Automatically inserts virtual `;` delimiters when statement boundaries are detected without crashing.
    - **Missing Closing Brackets / Braces**: Auto-closes missing `}` or `)` at scope boundaries.
    - **Stream Operator Recovery**: Recovers malformed `cout` and `cin` streams.

### Module 2: Semantic Analysis & Intelligent Error Recovery (`compiler/semantic.py`, `compiler/symbol_table.py`)
- **Scoped Symbol Table**:
  - Maintains hierarchical symbol scopes (global, function, nested blocks, loop headers).
  - Tracks symbol name, type, initialized state, line/column declaration, and usage counts.
- **Semantic Validation & AI Recovery**:
  - **Undeclared Variables**: Searches the current scope and parent scopes using fuzzy string matching. If a close match exists (e.g. `myCounter` vs `myCounte`), it suggests the match; otherwise, it auto-declares the variable with an inferred type (`int`) so subsequent compilation passes proceed without failing.
  - **Type Compatibility**: Checks type matching for assignments and expressions (int, float, bool, string).
  - **Uninitialized Variable Warnings**: Flags variables read before initialization.

### Module 3: Intermediate Code Generation & Optimization (`compiler/ir_generator.py`, `compiler/optimizer.py`)
- **TAC Generator**: Converts AST into a clean sequence of Three Address Code instructions (`result = arg1 op arg2`, `ifFalse t1 goto L2`, `print arg`, etc.).
- **Multi-Pass Optimizer**:
  1. **Constant Folding**: Evaluates compile-time expressions (e.g. `10 + 20` $\rightarrow$ `30`).
  2. **Constant Propagation**: Propagates known constants into subsequent instructions.
  3. **Strength Reduction**: Replaces expensive operations (e.g. `x * 2` $\rightarrow$ `x + x`, `x * 0` $\rightarrow$ `0`, `x * 1` $\rightarrow$ `x`, `x + 0` $\rightarrow$ `x`).
  4. **Common Subexpression Elimination (CSE)**: Identifies identical redundant expressions within basic blocks and reuses computed results.
  5. **Copy Propagation**: Eliminates intermediate temporary copies (`t2 = t1`).
  6. **Dead Code Elimination (DCE)**: Removes unused temporaries and unreachable code.

### Module 4: Target Code Generation & Runtime Execution (`compiler/codegen.py`, `compiler/runtime.py`)
- **Target Assembly Generator**: Translates optimized TAC into valid **x86-64 Intel assembly** with register allocation (`rax`, `rbx`, `rcx`, `rdx`, `r8d`, `r9d`, etc.), data section for string literals, and calling conventions for `printf`.
- **Runtime Execution Engines**:
  - **TAC Virtual Machine**: Fast built-in execution engine simulating memory, registers, program counter, and console output (`cout`).
  - **Native GCC Runner**: Directly invokes native `g++.exe` if installed to benchmark and run native binaries.

### Module 5: Performance Profiling and Test Suite (`compiler/profiler.py`, `tests/`)
- **Metrics Collected**:
  - Compilation Time (ms)
  - Execution Time (ms)
  - Memory Footprint (KB)
  - CPU Utilization (%)
  - Optimization Ratio (%) and Instructions Saved
  - Error Recovery Rate (%)
- **Unit and Integration Testing**: 16 automated tests covering all compilation phases and full pipeline workflows.

---

## 4. Software Interface (Slide 15 Replication)

The web user interface faithfully reproduces Slide 15:
- **Top Status Banner**: Live compilation indicator (`✓ Compilation successful` or `Auto-Recovered`).
- **Left Panel (C++ Source Code)**: Code editor with line numbers and controls:
  - `▶ Compile & Run`: Compiles, optimizes, and runs the active code.
  - `Load Example`: Loads the baseline Sum program from Slide 9 & 15 (`Sum = 30`).
  - `Loop Example`: Loads the loop summation program (`Loop Sum = 15`).
  - `Recovery Demo`: Loads a program with stray `@`, misspelled `itn`, and missing `;`.
  - `Optimizer Demo`: Demonstrates constant folding, strength reduction, CSE, and DCE.
  - `Clear`: Clears the editor.
- **Right Panel (Compiler Output Tabs)**:
  - `Diagnostics`: Detailed error detection log, AI suggestions, and auto-recovery actions.
  - `Tokens`: Interactive table with Token #, Type, Lexeme, Line, and Column.
  - `Intermediate Code`: Raw Three Address Code before optimization.
  - `Optimized Code`: Optimized TAC with applied optimization chips.
  - `Target Assembly`: x86-64 Intel assembly output.
  - `Program Output`: Terminal execution output (e.g. `Sum = 30`).
  - `Performance`: Metric cards reporting compile time, execution time, memory, CPU, optimization %, and recovery rate.
- **Bottom Feature Cards**: Displays Lexical Analysis, Syntax Analysis, Semantic Analysis, and Code Optimization descriptions.

---

## 5. How to Run

### Option A: Launch Web Interface (Recommended)
1. Double click `run_compiler.bat`, OR run from PowerShell:
   ```powershell
   python app.py
   ```
2. Open your browser and navigate to:
   ```
   http://127.0.0.1:5000
   ```

### Option B: Command Line Interface (CLI)
Compile and run any C++ source file from terminal:
```powershell
# Run default sum program with optimized code and performance report
python cli.py -o -p

# Compile custom file and emit target assembly
python cli.py my_program.cpp -s -e

# Run with diagnostics report
python cli.py my_program.cpp -d
```

### Option C: Run Automated Test Suite
Run the full test suite using pytest:
```powershell
python -m pytest -v
```
All 16 unit and integration tests validate lexing, parsing, error recovery, optimization passes, and full pipeline execution.

---

## 6. Project Structure

```
COMPILER DESIGN CAPSTON/
├── compiler/
│   ├── __init__.py           # Package exports
│   ├── tokens.py             # Token types and dataclasses
│   ├── lexer.py              # Module 1: Tokenizer & Damerau-Levenshtein recovery
│   ├── ast_nodes.py          # Abstract Syntax Tree hierarchy
│   ├── parser.py             # Module 1: Recursive descent parser & syntax recovery
│   ├── symbol_table.py       # Supporting: Scoped symbol table
│   ├── semantic.py           # Module 2: Semantic analyzer & AI recovery engine
│   ├── ir_generator.py       # Module 3: Three Address Code (TAC) generator
│   ├── optimizer.py          # Module 3: Multi-pass optimizer (folding, CSE, DCE)
│   ├── codegen.py            # Module 4: x86-64 target assembly generator
│   ├── runtime.py            # Module 4: Virtual Machine & native execution
│   └── profiler.py           # Module 5: Performance & optimization reporting
├── templates/
│   └── index.html            # Web UI template (Slide 15 layout)
├── static/
│   ├── css/
│   │   └── style.css         # Dark theme stylesheet matching Slide 15
│   └── js/
│       └── app.js            # Frontend interactivity, tab switching, API client
├── tests/                    # Module 5: Comprehensive test suite
│   ├── test_lexer.py
│   ├── test_parser.py
│   ├── test_semantic.py
│   ├── test_optimizer.py
│   └── test_full_pipeline.py
├── app.py                    # Flask server & REST API
├── cli.py                    # Command-line interface with full flag support
├── run_compiler.bat          # 1-click Windows launcher
└── README.md                 # Complete documentation
```
