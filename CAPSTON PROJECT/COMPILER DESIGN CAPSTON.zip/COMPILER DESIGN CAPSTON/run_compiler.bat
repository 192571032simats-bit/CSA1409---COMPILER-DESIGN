@echo off
title Intelligent Programming Language Compiler
echo =======================================================================
echo   Intelligent Programming Language Compiler with Error Recovery & Opt
echo   CSA1420 - COMPILER DESIGN CAPSTONE PROJECT
echo =======================================================================
echo.
echo Starting Web Interface on http://127.0.0.1:5000 ...
echo Opening default web browser...
start http://127.0.0.1:5000
echo.
python app.py
pause
