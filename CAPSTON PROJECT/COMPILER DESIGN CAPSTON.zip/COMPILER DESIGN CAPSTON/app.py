"""
Flask Web Application for Intelligent C++ Compiler
Implements API endpoints and serves the Slide 15 Compiler Interface.
"""

import os
import sys
from flask import Flask, render_template, request, jsonify
from compiler import IntelligentCompiler

app = Flask(__name__)
compiler = IntelligentCompiler()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/compile", methods=["POST"])
def compile_code():
    data = request.get_json() or {}
    source_code = data.get("source_code", "")
    use_native_gcc = data.get("use_native_gcc", False)

    if not source_code.strip():
        return jsonify({
            "status": {
                "message": "Source code is empty.",
                "level": "warning",
                "error_count": 0,
                "warning_count": 1,
                "recovered_count": 0
            },
            "tokens": [],
            "diagnostics": [{
                "phase": "Lexical",
                "severity": "Warning",
                "message": "Empty source code submitted.",
                "suggestion": "Write or load a C++ program into the editor.",
                "line": 1,
                "column": 1,
                "recovered": False,
                "action": "None"
            }],
            "symbol_table": {},
            "intermediate_code": "",
            "optimized_code": "",
            "target_assembly": "",
            "program_output": "",
            "applied_optimizations": [],
            "performance": {
                "compilation_time_ms": 0.0,
                "execution_time_ms": 0.0,
                "memory_usage_kb": 0.0,
                "cpu_utilization_pct": 0.0,
                "optimization_percentage": 0.0,
                "error_recovery_rate": 100.0,
                "total_errors_detected": 0,
                "errors_recovered": 0,
                "initial_instructions": 0,
                "optimized_instructions": 0,
                "instructions_saved": 0,
                "vm_cycles": 0
            }
        })

    result = compiler.compile_and_run(source_code, use_native_gcc=use_native_gcc)
    return jsonify(result)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting Intelligent Compiler Web Interface on http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False)
